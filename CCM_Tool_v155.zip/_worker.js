/* ─────────────────────────────────────────────────────────────────────────
   CCM Clinical Tool — usage tracking worker

   Pages Direct Upload (drag-and-drop) does NOT compile a functions/ folder;
   that only happens when Pages runs a build. A root-level _worker.js IS
   supported by Direct Upload, so both endpoints live here and everything
   else is handed to the static assets.

   Records ONLY: date, agent name, agent code, device id, event kind, tab.
   Never receives clinical text, ICD codes, or medication lists.
   ───────────────────────────────────────────────────────────────────────── */

const TTL = 60 * 60 * 24 * 400;          /* ~13 months of history */
/* v140: tab-switch pings are bucketed into windows this wide before being
   written to KV -- see handlePing. Mohamed's pick of 10-15 minutes;
   10 chosen as the default, change this one constant to retune. */
const PING_WINDOW_MIN = 10;
/* The tool's tabs, exactly as switchTab() in index.html beacons them.
   handleStats used to carry its own copy of this list WITHOUT 'careplan',
   so every Problem Note Generator open was written to KV and then never read
   back — the tab existed in the tool, in the beacon and in the store, and was
   invisible in the report. One list, one place. */
const TABS = ['reference', 'analyzer', 'prognotes', 'loinc', 'templates', 'careplan'];
/* The widest window /api/stats will serve in one request. Each day costs one
   list call per tab plus one for opens, so an unbounded range would hang;
   KV keeps ~13 months, so a longer span is a matter of several requests. */
const MAX_SPAN_DAYS = 92;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/ping')  return handlePing(request, env);
    if (url.pathname === '/api/stats') return handleStats(url, env);
    if (url.pathname === '/api/unknown') return handleUnknown(request, env);
    if (url.pathname === '/api/roster' && request.method === 'GET')  return handleRosterGet(env);
    if (url.pathname === '/api/roster' && request.method === 'POST') return handleRosterPost(request, env);
    if (url.pathname === '/api/owner-auth' && request.method === 'POST') return handleOwnerAuth(request, env);
    if (url.pathname === '/api/selfreg' && request.method === 'GET')  return handleSelfRegGet(url, env);
    if (url.pathname === '/api/selfreg' && request.method === 'POST') return handleSelfRegPost(request, env);
    if (url.pathname === '/dashboard' || url.pathname === '/dashboard/')
      return new Response(DASHBOARD, { headers: {
        'content-type': 'text/html; charset=utf-8',
        'cache-control': 'no-store',
        'x-robots-tag': 'noindex, nofollow'
      }});

    return env.ASSETS.fetch(request);     /* everything else = the tool itself */
  }
};

async function handlePing(request, env) {
  if (request.method !== 'POST')
    return new Response('Method Not Allowed', { status: 405 });
  try {
    if (!env.CCM_USAGE) return new Response(null, { status: 204 });

    const b = await request.json();
    const day = String(b.day || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return new Response(null, { status: 204 });

    const agent = String(b.agent || 'unknown').slice(0, 80).replace(/[\r\n]/g, ' ');
    const code  = String(b.code  || '').replace(/[^0-9]/g, '').slice(0, 10);
    const id    = String(b.id    || '').replace(/[^a-z0-9]/gi, '').slice(0, 40);
    const kind  = b.kind === 'tab' ? 'tab' : 'open';
    const tab   = String(b.detail || '').replace(/[^a-z]/gi, '').slice(0, 20);

    /* The agent code goes IN THE KEY. Reading a value for every key blew past
       Cloudflare's 1,000-subrequest limit once real usage accumulated, which is
       what produced the 500 on /api/stats. Key listing alone is now enough. */
    const who = code || 'x';
    const at  = String(b.at || '').replace(/[^0-9]/g, '').slice(0, 6) || '000000';
    /* Tab events are one key per use, so listing them gives a real count.
       Opens stay one key per device per day. */
    if (kind === 'tab') {
      /* v140: one KV WRITE per agent+tab per PING_WINDOW_MIN-minute window,
         not one per switch. Confirmed root cause of "Save failed: ... the
         storage account hit a write limit for today" -- this path writes a
         brand-new key per tab-switch event with no dedup, and with ~171
         agents across 5 tabs that burns Cloudflare KV's daily write quota
         well before Mohamed gets to the roster admin panel later in his
         shift. His choice of the three options laid out: throttle, not full
         dedup -- a day still accumulates a per-tab window count, just a
         coarser one than raw event counts. */
      const hh = at.slice(0, 2), mm = parseInt(at.slice(2, 4), 10) || 0;
      const bucketMin = Math.floor(mm / PING_WINDOW_MIN) * PING_WINDOW_MIN;
      const window = hh + String(bucketMin).padStart(2, '0');
      const key = `t:${day}:${tab}:${who}:${id}:${window}`;
      const already = await env.CCM_USAGE.get(key);
      if (already === null) {
        await env.CCM_USAGE.put(key, JSON.stringify({ agent, code, build: String(b.build || '') }),
                                { expirationTtl: TTL });
      }
      return new Response(null, { status: 204 });
    }
    const key = `d:${day}:${who}:${id}`;
    await env.CCM_USAGE.put(key, JSON.stringify({ agent, code, build: String(b.build || '') }),
                            { expirationTtl: TTL });
    return new Response(null, { status: 204 });
  } catch (e) {
    return new Response(null, { status: 204 });   /* never surface errors to the tool */
  }
}

async function handleStats(url, env) {
  const supplied = (url.searchParams.get('token') || '').trim();
  const expected = String(env.STATS_TOKEN || '').trim();
  if (!expected || supplied !== expected)
    return new Response('unauthorized', { status: 401 });
  if (!env.CCM_USAGE)
    return json({ error: 'CCM_USAGE KV namespace is not bound' }, 500);

  try {
    /* Range. `from`/`to` (YYYY-MM-DD) is the real control; `days` is kept so an
       older cached page still works. Both resolve to the same day list. */
    const isDay = s => /^\d{4}-\d{2}-\d{2}$/.test(s || '');
    const dayStr = d => d.toISOString().slice(0, 10);
    const qFrom = (url.searchParams.get('from') || '').trim();
    const qTo   = (url.searchParams.get('to')   || '').trim();
    const today = new Date();
    let dayList = [];
    if (isDay(qFrom) && isDay(qTo)) {
      let a = qFrom, b = qTo;
      if (a > b) { const t = a; a = b; b = t; }
      const start = new Date(a + 'T00:00:00Z'), end = new Date(b + 'T00:00:00Z');
      for (let t = end.getTime(); t >= start.getTime(); t -= 86400000) {
        dayList.push(dayStr(new Date(t)));
        if (dayList.length >= MAX_SPAN_DAYS) break;
      }
    } else {
      const days = Math.min(parseInt(url.searchParams.get('days') || '30', 10) || 30,
                            MAX_SPAN_DAYS);
      for (let i = 0; i < days; i++)
        dayList.push(dayStr(new Date(today.getTime() - i * 86400000)));
    }
    const out = { days: [], totals: { uniqueAgents: 0, tabs: {} } };
    const everyone = new Set();

    /* Keys carry the agent code, so a day costs ONE list call and no value
       reads. Older keys (before v77) lack the code and simply count as
       activity without a name. */
    /* Agent codes are always numeric. Keys written before v77 put the device id
       in this position, so anything non-numeric is legacy: it still counts as
       activity, but must never be presented as an agent. */
    const parse = (name, parts) => {
      const p = String(name).split(':');
      const c = p.length >= parts + 1 ? p[parts] : null;
      return (c && /^[0-9]+$/.test(c)) ? c : null;
    };

    /* One day's buckets. Pulled out of the loop so the days can run in
       parallel — sequential await over a quarter's worth of days is slow
       enough to time the request out. */
    const readDay = async (day) => {

      const openKeys = await listAll(env.CCM_USAGE, `d:${day}:`);
      const per = {};
      const codes = new Set();
      let legacyOpens = 0;
      for (const k of openKeys) {
        const c = parse(k.name, 2);
        if (c) { codes.add(c); everyone.add(c); per[c] = per[c] || { code: c, tabs: [], counts: {} }; }
        else legacyOpens++;
      }

      /* v150: ONE list call for the whole day's tab events, split by the tab
         name inside each key (t:<day>:<tab>:<code>:<id>:<window>). It used to
         be one call per tab -- 7 list calls a day, 420 for the dashboard's
         default 30 days plus the 30 before them -- against Cloudflare's free
         1,000-list-operations-a-day allowance, so a couple of dashboard loads
         could use the day up. Tabs outside TABS are ignored, as before. */
      const tabs = {};
      let legacyTabs = 0;
      const tabKeys = await listAll(env.CCM_USAGE, `t:${day}:`);
      for (const k of tabKeys) {
        const tab = String(k.name).split(':')[2];
        if (TABS.indexOf(tab) === -1) continue;
        tabs[tab] = (tabs[tab] || 0) + 1;
        const c = parse(k.name, 3);
        if (!c) { legacyTabs += 1; continue; }
        codes.add(c); everyone.add(c);
        per[c] = per[c] || { code: c, tabs: [], counts: {} };
        if (per[c].tabs.indexOf(tab) === -1) per[c].tabs.push(tab);
        per[c].counts[tab] = (per[c].counts[tab] || 0) + 1;
      }

      if (!codes.size && !Object.keys(tabs).length) return null;
      return {
        day,
        activeDevices: openKeys.length,
        legacy: { opens: legacyOpens, tabs: legacyTabs },
        agents: [...codes].sort(),
        tabs,
        detail: Object.values(per).map(r => ({ code: r.code, name: '', tabs: r.tabs.sort(),
                                               counts: r.counts || {},
                                               total: Object.values(r.counts || {}).reduce((a, b) => a + b, 0) }))
      };
    };

    /* Bounded concurrency: wide enough that a quarter returns promptly,
       narrow enough not to flood KV. */
    const CHUNK = 12;
    for (let i = 0; i < dayList.length; i += CHUNK) {
      const batch = await Promise.all(dayList.slice(i, i + CHUNK).map(readDay));
      for (const r of batch) if (r) out.days.push(r);
    }
    out.days.sort((a, b) => b.day.localeCompare(a.day));
    out.range = { from: dayList[dayList.length - 1] || '', to: dayList[0] || '',
                  days: dayList.length, maxSpan: MAX_SPAN_DAYS };
    out.tabIds = TABS;

    /* Unknown medications: a bounded number of value reads. */
    const unk = (await listAll(env.CCM_USAGE, 'u:')).slice(0, 120);
    out.unknownMeds = [];
    const vals = await Promise.all(unk.map(k => env.CCM_USAGE.get(k.name, 'json')));
    for (const v of vals)
      if (v && v.name)
        out.unknownMeds.push({ name: v.name, total: v.total || 0,
                               agents: (v.agents || []).length, last: v.last || '' });
    out.unknownMeds.sort((a, b) => b.total - a.total || b.agents - a.agents);

    for (const d of out.days)
      for (const [tab, n] of Object.entries(d.tabs || {}))
        out.totals.tabs[tab] = (out.totals.tabs[tab] || 0) + n;
    out.totals.uniqueAgents = everyone.size;
    out.totals.agentList = [...everyone].sort();
    return json(out, 200);
  } catch (e) {
    /* v150: say WHY. A Cloudflare quota/limit refusal is named as such so the
       dashboard can show it instead of a bare "Server returned 500". */
    const msg = String(e && e.message || e);
    const limit = /quota|exceeded|limit|too many/i.test(msg);
    return json({ error: limit ? 'storage limit reached' : 'stats failed', detail: msg }, 500);
  }
}

/* POST /api/unknown — medication names the tool could not identify.
   Sent only when an agent presses the button after seeing the exact list.
   Names are re-sanitised here: letters, spaces and hyphens only. */
async function handleUnknown(request, env) {
  if (request.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });
  try {
    if (!env.CCM_USAGE) return new Response(null, { status: 204 });
    const b = await request.json();
    const day = String(b.day || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return new Response(null, { status: 204 });
    const code = String(b.code || '').replace(/[^0-9]/g, '').slice(0, 10);
    const rows = Array.isArray(b.names) ? b.names.slice(0, 60) : [];
    for (const r of rows) {
      const name = String(r && r.n || '').replace(/[^A-Za-z\- ]/g, '').trim().slice(0, 60).toLowerCase();
      if (name.length < 3) continue;
      /* The client already refuses anything that is not a medication name, but a
         direct POST bypasses the client. Apply the SAME rules here: a real order
         names a dosage form, and identifiers are never accepted. */
      if (!/\b(?:tablet|capsule|caplet|solution|suspension|injection|injectable|syringe|cream|ointment|gel|lotion|shampoo|patch|powder|packet|granules|syrup|elixir|aerosol|inhaler|inhalation|nebulizer|spray|drop|drops|suppository|enema|foam|injector|vial|troche|lozenge|oral|topical|nasal|ophthalmic|otic|rectal|transdermal|subcutaneous|intramuscular|external|chewable)\b/.test(name)) continue;
      if (/\b(?:patient|resident|dob|mrn|room|bed|mr|mrs|ms|miss|male|female|age)\b/.test(name)) continue;
      const count = Math.min(parseInt(r.c, 10) || 1, 999);
      const key = `u:${name}`;
      const prev = await env.CCM_USAGE.get(key, 'json');
      await env.CCM_USAGE.put(key, JSON.stringify({
        name,
        total: ((prev && prev.total) || 0) + count,
        agents: [...new Set([...(((prev && prev.agents) || [])), code].filter(Boolean))].slice(0, 40),
        last: day
      }), { expirationTtl: TTL });
    }
    return new Response(null, { status: 204 });
  } catch (e) { return new Response(null, { status: 204 }); }
}

/* ─────────────────────────────────────────────────────────────────────────
   v105: server-side roster storage. Lets Mohamed add/remove agents and move
   them between shifts from the tool's own admin panel — no rebuild, no
   redeploy — instead of the roster only ever being a hardcoded array baked
   into index.html. GET is public (every agent's browser reads it on load);
   POST is gated by the SAME secret already used for the /dashboard stats
   page (STATS_TOKEN), so nobody but Mohamed can rewrite the roster.

   Stored WITHOUT an expirationTtl on purpose — every other key in this file
   uses TTL because usage history is meant to age out; the roster must never
   silently vanish just because nobody edited it in a while. */
const ROSTER_KEY = 'roster:current';
/* v137: 'Officers' was missing here. v126 added that group for staff on no clock
   shift (L&D, and QC since v136) and was careful to put it in BOTH places it
   appears in index.html — the sign-in picker's optgroup order and the admin
   panel's SHIFTS array — but this validator is a THIRD list, on the server, and
   it still held the v105 set. It never surfaced because the roster being saved
   had no officer in it until now: Mohamed hit "Save failed: Abdallah Ahmed
   Abdallah Farag has an unrecognised shift" the first time he tried to save a
   roster containing one. A test now derives the allowed set from the admin
   panel's own dropdown and asserts the real Worker accepts every value, so a
   fourth list cannot drift from the others. */
const ROSTER_SHIFTS = ['Morning', 'Afternoon', 'Night', 'Officers', 'Unassigned'];
/* Must match CCM_TRACK.owner in index.html. The owner is synthesized into
   the picker client-side and is never part of this editable array, so a
   collision here would only ever mean a mistaken/duplicate entry — reject
   it outright rather than silently accepting a roster that could confuse
   who "the owner" is. */
const OWNER_CODE = '1233';

async function handleRosterGet(env) {
  try {
    if (!env.CCM_USAGE) return json({ roster: null }, 200);
    const v = await env.CCM_USAGE.get(ROSTER_KEY, 'json');
    if (!v || !Array.isArray(v.roster)) return json({ roster: null }, 200);
    return json({ roster: v.roster, updatedAt: v.updatedAt || '', updatedBy: v.updatedBy || '' }, 200);
  } catch (e) {
    return json({ roster: null }, 200);   /* never block sign-in over a read error */
  }
}

async function handleRosterPost(request, env) {
  try {
    let b;
    try { b = await request.json(); } catch (e) { return json({ error: 'bad json body' }, 400); }

    const expected = String(env.STATS_TOKEN || '').trim();
    const supplied = String((b && b.token) || '').trim();
    if (!expected || supplied !== expected) return json({ error: 'unauthorized' }, 401);
    if (!env.CCM_USAGE) return json({ error: 'CCM_USAGE KV namespace is not bound' }, 500);

    const rawRoster = Array.isArray(b.roster) ? b.roster : null;
    if (!rawRoster) return json({ error: 'roster must be an array' }, 400);
    if (rawRoster.length > 400) return json({ error: 'too many entries (max 400)' }, 400);

    const seen = new Set();
    const clean = [];
    for (const row of rawRoster) {
      if (!Array.isArray(row) || row.length < 3)
        return json({ error: 'every entry needs [name, code, shift]' }, 400);
      const name  = String(row[0] || '').trim().slice(0, 80);
      const code  = String(row[1] || '').replace(/[^0-9]/g, '').slice(0, 10);
      const shift = String(row[2] || '').trim();
      if (!name)  return json({ error: 'an entry is missing a name' }, 400);
      if (!code)  return json({ error: `"${name}" has no numeric code` }, 400);
      if (ROSTER_SHIFTS.indexOf(shift) === -1)
        return json({ error: `"${name}" has an unrecognised shift: "${shift}"` }, 400);
      if (code === OWNER_CODE)
        return json({ error: `code ${OWNER_CODE} is reserved for the owner and cannot be in the regular roster` }, 400);
      if (seen.has(code)) return json({ error: `duplicate code ${code}` }, 400);
      seen.add(code);
      clean.push([name, code, shift]);
    }

    const updatedBy = String((b && b.updatedBy) || '').trim().slice(0, 80) || 'unknown';
    const payload = { roster: clean, updatedAt: new Date().toISOString(), updatedBy };
    await env.CCM_USAGE.put(ROSTER_KEY, JSON.stringify(payload));   /* no TTL — must never expire */
    return json({ ok: true, roster: clean, updatedAt: payload.updatedAt, updatedBy, count: clean.length }, 200);
  } catch (e) {
    /* v138: Mohamed hit this after v137 fixed the "unrecognised shift" bug —
       the save got PAST validation and then the KV write itself threw. The raw
       message still rides along as `detail` (the client now shows it, v138),
       but a flat "roster update failed" gave no hint whether retrying was
       worth it. These are the two Cloudflare KV failure shapes that matter
       for that: a per-key rate limit is transient, a quota/limit is not. */
    const msg = String(e && e.message || e);
    let error = 'roster update failed';
    if (/rate.?limit|429/i.test(msg))
      error = 'roster update failed — too many saves too fast; wait a few seconds and try again';
    else if (/quota|exceeded|limit/i.test(msg))
      error = 'roster update failed — the storage account hit a write limit for today';
    return json({ error, detail: msg }, 500);
  }
}

/* v106: gates the sign-in step itself, not just the roster write. Before this,
   anyone could pick "Mohamed Hossam" from the same public name list every
   agent sees and become the owner session — no secret required. Checked
   server-side (never a client-side string compare, which view-source would
   expose) against the SAME token that already protects /api/roster's POST
   and /dashboard, per Mohamed's own choice — one secret, nothing new to set
   up in Cloudflare. No KV involved; this never reads or writes CCM_USAGE. */
/* ===========================================================================
   /api/selfreg - new-hire self registration (v134)
   ---------------------------------------------------------------------------
   v133 made the code the only way in, which closed the "pick anyone from the
   list" hole but left a hire whose code is not on the roster yet with no way in
   at all. The workaround for that is borrowing a colleague's code, so the fix
   has to give them a real door: register themselves, use the tool under their
   OWN code, and show up in a list Mohamed approves.

   Nothing here writes to roster:current. Approving is a human action in the
   admin panel, which then saves the roster through the existing, token-gated
   /api/roster POST. A self-registration can never add anyone to the live list.
   =========================================================================== */
const SELF_PREFIX = 'sr:';
const SELF_SHIFTS = ['Morning', 'Afternoon', 'Night'];

async function handleSelfRegPost(request, env) {
  try {
    if (!env.CCM_USAGE) return new Response(null, { status: 204 });
    const b = await request.json();

    /* ---- owner action: dismiss one ---- */
    if (b && b.dismiss !== undefined) {
      const expected = String(env.STATS_TOKEN || '').trim();
      const supplied = String(b.token || '').trim();
      if (!expected || supplied !== expected)
        return new Response('unauthorized', { status: 401 });
      const code = String(b.dismiss || '').replace(/[^0-9]/g, '').slice(0, 10);
      if (!code) return json({ error: 'no code given' }, 400);
      await env.CCM_USAGE.delete(SELF_PREFIX + code);
      return json({ ok: true, dismissed: code });
    }

    /* ---- the hire's own registration ---- */
    const name  = String(b.name  || '').slice(0, 80).replace(/[\r\n]/g, ' ').trim();
    const code  = String(b.code  || '').replace(/[^0-9]/g, '').slice(0, 10);
    const shift = String(b.shift || '').trim();
    /* Silent on bad input, exactly like handlePing: the tool must never show an
       error here, and the hire is already signed in locally by this point. But
       nothing is written either - a registration with no shift or the owner's
       code would be worse than none. */
    if (!name || !code) return new Response(null, { status: 204 });
    if (SELF_SHIFTS.indexOf(shift) === -1) return new Response(null, { status: 204 });
    if (code === '1233') return new Response(null, { status: 204 });

    /* One key per code, overwritten on repeat, so a hire opening the tool again
       cannot flood the list. */
    await env.CCM_USAGE.put(SELF_PREFIX + code, JSON.stringify({
      name: name, code: code, shift: shift,
      collision: !!b.collision,
      build: String(b.build || '').slice(0, 20),
      at: new Date().toISOString()
    }), { expirationTtl: TTL });
    return new Response(null, { status: 204 });
  } catch (e) {
    return new Response(null, { status: 204 });
  }
}

async function handleSelfRegGet(url, env) {
  const supplied = (url.searchParams.get('token') || '').trim();
  const expected = String(env.STATS_TOKEN || '').trim();
  if (!expected || supplied !== expected)
    return new Response('unauthorized', { status: 401 });
  if (!env.CCM_USAGE) return json({ pending: [] });
  try {
    const keys = (await env.CCM_USAGE.list({ prefix: SELF_PREFIX })).keys || [];
    const out = [];
    for (const k of keys) {
      const raw = await env.CCM_USAGE.get(k.name);
      if (!raw) continue;
      try { out.push(JSON.parse(raw)); } catch (e) { /* skip a corrupt row */ }
    }
    out.sort((a, b) => String(b.at || '').localeCompare(String(a.at || '')));
    return json({ pending: out, count: out.length });
  } catch (e) {
    return json({ error: 'could not read pending registrations' }, 500);
  }
}

async function handleOwnerAuth(request, env) {
  try {
    let b; try { b = await request.json(); } catch (e) { return json({ ok: false, error: 'bad json body' }, 400); }
    const expected = String(env.STATS_TOKEN || '').trim();
    const supplied = String((b && b.password) || '').trim();
    if (!expected || supplied !== expected) return json({ ok: false }, 401);
    return json({ ok: true }, 200);
  } catch (e) {
    return json({ ok: false, error: 'auth failed' }, 500);
  }
}

async function listAll(kv, prefix) {
  const acc = []; let cursor;
  do {
    const r = await kv.list({ prefix, cursor });
    acc.push(...r.keys);
    if (r.list_complete) break;
    cursor = r.cursor;
  } while (cursor);
  return acc;
}

function json(obj, status) {
  return new Response(JSON.stringify(obj, null, 2),
                      { status, headers: { 'content-type': 'application/json' } });
}


/* Adoption dashboard at /dashboard. Token entered in-page, never in the URL. */
const DASHBOARD = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>CCM Tool — Adoption</title>
<style>
:root{
  --ink:#0b1f1c; --ink2:#33534d; --mut:#7c9691; --line:#dfe8e5; --hair:#eef3f2;
  --paper:#f6f8f7; --card:#fff; --deep:#0f766e; --live:#14b8a6; --dim:#cbd9d6;
  --flag:#b45309; --flagbg:#fffbeb;
}
*{box-sizing:border-box}
body{margin:0;background:var(--paper);color:var(--ink);
  font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;-webkit-font-smoothing:antialiased}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-variant-numeric:tabular-nums}
.wrap{max-width:1000px;margin:0 auto;padding:30px 22px 70px}

header{display:flex;align-items:baseline;justify-content:space-between;gap:16px;flex-wrap:wrap;
  padding-bottom:14px;border-bottom:2px solid var(--ink);margin-bottom:26px}
h1{font-size:19px;font-weight:640;letter-spacing:-.01em;margin:0}
h1 span{color:var(--mut);font-weight:400}
.period{font-size:12.5px;color:var(--mut);letter-spacing:.02em}

.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(158px,1fr));gap:1px;
  background:var(--line);border:1px solid var(--line);border-radius:8px;overflow:hidden;margin-bottom:30px}
.kpi{background:var(--card);padding:15px 17px}
.kpi .n{font-size:27px;font-weight:600;letter-spacing:-.02em;line-height:1.15;color:var(--deep)}
.kpi .n.flat{color:var(--mut)}
.kpi .n.up{color:var(--live)}
.kpi .n.down{color:var(--flag)}
.kpi .l{font-size:11px;color:var(--mut);text-transform:uppercase;letter-spacing:.07em;margin-top:5px}
.kpi .s{font-size:11.5px;color:var(--mut);margin-top:3px}

h2{font-size:11.5px;text-transform:uppercase;letter-spacing:.09em;color:var(--ink2);
  margin:0 0 3px;font-weight:640}
h3.shifthead{font-size:12.5px;font-weight:640;color:var(--ink);margin:18px 0 6px;
  display:flex;align-items:baseline;gap:9px}
h3.shifthead:first-child{margin-top:4px}
h3.shifthead span{font-size:11.5px;font-weight:400;color:var(--mut);
  font-variant-numeric:tabular-nums}
.hint{font-size:12.5px;color:var(--mut);margin:0 0 15px}
section{margin-bottom:34px}

/* signature: the roster board */
.board{display:grid;grid-template-columns:repeat(auto-fit,minmax(216px,1fr));gap:10px}
.team{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:14px 16px 16px}
.team.none{background:var(--flagbg);border-color:#f0d9a8}
.team .top{display:flex;align-items:baseline;justify-content:space-between;margin-bottom:2px}
.team .who{font-size:14.5px;font-weight:600}
.team .cnt{font-size:12.5px;color:var(--mut)}
.team .cnt b{color:var(--deep);font-weight:600}
.team.none .cnt b{color:var(--flag)}
.team .sh{font-size:10.5px;color:var(--mut);text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px}
.dots{display:flex;flex-wrap:wrap;gap:5px}
.dot{width:15px;height:15px;border-radius:4px;background:var(--card);
  border:1.5px solid var(--dim);cursor:default}
.dot.on{background:var(--live);border-color:var(--live)}
.dot.hot{background:var(--deep);border-color:var(--deep)}

/* filter row — one row, above everything it scopes */
.filters{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 24px;
  padding-bottom:16px;border-bottom:1px solid var(--line)}
.filters .lbl{font-size:11px;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);
  margin-right:2px}
.preset{font:inherit;font-size:12.5px;padding:5px 11px;border:1px solid var(--line);
  background:var(--card);color:var(--ink2);border-radius:999px;cursor:pointer;
  transition:background .12s,border-color .12s}
.preset:hover{background:var(--hair)}
.preset[aria-pressed="true"]{background:var(--deep);border-color:var(--deep);color:#fff;font-weight:600}
.filters input[type="date"]{font:inherit;font-size:12.5px;padding:4px 8px;color:var(--ink2);
  border:1px solid var(--line);border-radius:7px;background:var(--card)}
.filters .sep{width:1px;height:20px;background:var(--line);margin:0 4px}
.filters .note{font-size:11.5px;color:var(--mut)}
#app.busy .scoped{opacity:.45;transition:opacity .12s}

/* charts */
.chartgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:18px}
.chart{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:15px 16px 12px}
.chart h3{font-size:12.5px;font-weight:640;color:var(--ink);margin:0 0 2px}
.chart .sub{font-size:11.5px;color:var(--mut);margin:0 0 10px}
.chart svg{display:block;width:100%;height:auto;overflow:visible}
.chart .empty{font-size:12.5px;color:var(--mut);padding:18px 0}
.tip{position:fixed;z-index:50;pointer-events:none;background:var(--ink);color:#fff;
  font-size:11.5px;line-height:1.45;padding:6px 9px;border-radius:6px;opacity:0;
  transition:opacity .09s;white-space:nowrap;box-shadow:0 4px 14px rgba(0,0,0,.22)}
.tip.on{opacity:1}
.tip b{font-weight:600}

/* daily strip */
.strip{display:flex;align-items:flex-end;gap:6px;height:112px}
.col{flex:0 0 46px;display:flex;flex-direction:column;justify-content:flex-end;align-items:center}
.col .b{width:100%;background:var(--deep);border-radius:2px 2px 0 0;min-height:3px}
.col .b.wk{background:var(--dim)}
.col .v{font-size:11px;font-weight:600;margin-bottom:4px}
.col .d{font-size:10px;color:var(--mut);margin-top:5px}

/* bars */
.bar{display:flex;align-items:center;gap:11px;margin-bottom:6px;font-size:13px}
.bar .lb{width:118px;flex:0 0 118px;text-align:right;color:var(--ink2)}
.bar .tr{flex:1;background:var(--hair);border-radius:3px;height:19px;position:relative;overflow:hidden}
.bar .fl{position:absolute;inset:0 auto 0 0;background:var(--live);border-radius:3px}
.bar .vl{width:64px;flex:0 0 64px;font-weight:600;font-size:12.5px}

table{width:100%;border-collapse:collapse;font-size:13.5px}
th{text-align:left;font-size:10.5px;text-transform:uppercase;letter-spacing:.07em;color:var(--mut);
  border-bottom:1px solid var(--line);padding:7px 9px;font-weight:640}
td{padding:7px 9px;border-bottom:1px solid var(--hair)}
tr:last-child td{border-bottom:0}
details{border:1px solid var(--line);border-radius:8px;background:var(--card);margin-bottom:9px}
summary{cursor:pointer;padding:11px 15px;font-size:13.5px;list-style:none;display:flex;
  justify-content:space-between;align-items:center;gap:12px}
summary::-webkit-details-marker{display:none}
summary .n{color:var(--flag);font-weight:600;font-size:12.5px}
details[open] summary{border-bottom:1px solid var(--hair)}
details .body{padding:4px 15px 12px}
.names{columns:2;column-gap:22px;font-size:13px;color:var(--ink2)}
.names div{break-inside:avoid;padding:2px 0}
.empty{font-size:13px;color:var(--mut);padding:14px 0;font-style:italic}
.gwrap{overflow-x:auto;border:1px solid var(--line);border-radius:8px;background:var(--card)}
table.grid{border-collapse:separate;border-spacing:0;font-size:12.5px;width:100%}
table.grid th{position:sticky;top:0;background:var(--card);z-index:2;padding:6px 4px;text-align:center;font-size:10px;white-space:nowrap;border-bottom:1px solid var(--line)}
table.grid th.who{text-align:left;left:0;z-index:3;min-width:186px;padding-left:12px}
table.grid td{padding:2px 3px;text-align:center;border-bottom:1px solid var(--hair)}
table.grid td.who{text-align:left;position:sticky;left:0;background:var(--card);z-index:1;padding-left:12px;white-space:nowrap;cursor:pointer}
table.grid td.who:hover{color:var(--deep);text-decoration:underline}
table.grid tr:last-child td{border-bottom:0}
.cell{display:inline-block;width:16px;height:16px;border-radius:3px;background:var(--hair)}
.cell.on{background:var(--live)}
.cell.hot{background:var(--deep)}
.gcode{color:var(--mut);font-size:11px;margin-left:5px}
.detail{margin-top:14px;border:1px solid var(--line);border-radius:8px;background:var(--card);padding:14px 16px}
.detail h3{margin:0 0 10px;font-size:14.5px}
.tabchip{display:inline-block;font-size:11px;padding:1px 7px;border-radius:99px;background:#ecfdf5;color:#047857;margin-right:4px}

.gate{max-width:370px;margin:14vh auto;background:var(--card);border:1px solid var(--line);
  border-radius:10px;padding:26px 26px 22px}
.gate h1{margin-bottom:4px}
input,button{font:inherit}
.gate input{width:100%;padding:9px 12px;border:1px solid var(--line);border-radius:7px;margin:14px 0 10px;
  background:var(--paper)}
.gate input:focus{outline:2px solid var(--live);outline-offset:1px}
.gate button{width:100%;padding:10px;background:var(--deep);color:#fff;border:0;border-radius:7px;
  cursor:pointer;font-weight:550}
.gate button:hover{background:#0b5f58}
button:focus-visible{outline:2px solid var(--ink);outline-offset:2px}
.err{color:#b91c1c;font-size:12.5px;min-height:18px;margin-top:6px}
.fine{font-size:11.5px;color:var(--mut);margin-top:10px;line-height:1.45}
@media (max-width:560px){.names{columns:1}.bar .lb{width:88px;flex:0 0 88px}}
</style></head><body>

<div class="gate card" id="gate">
  <h1>CCM Tool <span>— Adoption</span></h1>
  <div class="period">Enter the stats token to continue.</div>
  <input id="tok" type="password" placeholder="Stats token" autocomplete="off" aria-label="Stats token">
  <button id="go">Open dashboard</button>
  <div class="err" id="err" role="status"></div>
  <div class="fine">Held for this browser tab only. Never written to the address bar.</div>
</div>

<div class="wrap" id="app" style="display:none">
  <header>
    <h1>CCM Tool <span>— Adoption</span></h1>
    <div style="text-align:right">
      <div class="period mono" id="period"></div>
      <div class="period mono" id="rosterStamp"></div>
    </div>
  </header>

  <div class="filters" id="filters">
    <span class="lbl">Range</span>
    <button class="preset" data-days="7">Last 7 days</button>
    <button class="preset" data-days="30">Last 30 days</button>
    <button class="preset" data-days="90">Last 90 days</button>
    <button class="preset" data-mtd="1">This month</button>
    <button class="preset" data-lastmonth="1">Last month</button>
    <span class="sep"></span>
    <input type="date" id="fFrom" aria-label="From date">
    <span class="note">to</span>
    <input type="date" id="fTo" aria-label="To date">
    <button class="preset" id="fApply">Apply</button>
    <span class="note" id="fNote"></span>
  </div>

  <div class="kpis scoped" id="kpis"></div>

  <section class="scoped">
    <h2>Analysis</h2>
    <p class="hint">Everything on this page is scoped to the range above.</p>
    <div class="chartgrid">
      <div class="chart" style="grid-column:1/-1">
        <h3>Agents using the tool each day</h3>
        <p class="sub" id="cDailySub"></p>
        <div id="cDaily"></div>
      </div>
      <div class="chart">
        <h3>Adoption by team</h3>
        <p class="sub">Share of each SME's agents who opened the tool at least once in the range.</p>
        <div id="cTeams"></div>
      </div>
      <div class="chart">
        <h3>How often agents come back</h3>
        <p class="sub" id="cDepthSub">Agents grouped by how many days they used the tool.</p>
        <div id="cDepth"></div>
      </div>
    </div>
  </section>

  <section class="scoped">
    <h2>Coverage by team</h2>
    <p class="hint">One card per SME, in shift order, with the hours that team works.
       One square per agent: filled squares opened the tool during the selected range,
       solid dark means 3 or more days.</p>
    <div class="board" id="board"></div>
  </section>

  <section class="scoped">
    <h2>Which tabs get used</h2>
    <p class="hint">Counts each agent once per tab per day.</p>
    <div id="tabs"></div>
  </section>

  <section class="scoped">
    <h2>Follow-up lists</h2>
    <p class="hint">Agents who have not opened the tool during the selected range, grouped by delegate.</p>
    <div id="followup"></div>
  </section>

  <section class="scoped">
    <h2>Day detail</h2>
    <p class="hint">Pick a date to see exactly who used the tool that day and how many times they
       opened each tab.</p>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
      <select id="dayPick" style="padding:8px 11px;border:1px solid var(--line);border-radius:7px;font-size:14px;min-width:210px"></select>
      <span id="daySummary" class="hint" style="margin:0"></span>
    </div>
    <div id="dayDetail"></div>
  </section>

  <section class="scoped">
    <h2>Individual daily activity</h2>
    <p class="hint">The last 14 days of the selected range, one column per day.</p>
    <p class="hint">Every agent, every day, and which tabs they opened. Hover a square for the detail;
       click a name for the day-by-day breakdown.</p>
    <div id="gridwrap"></div>
    <div id="agentDetail"></div>
  </section>

  <section>
    <h2>Medications the tool cannot identify</h2>
    <p class="hint">Reported by agents from real pastes. This is the list to work through — ranked by
       how often it comes up, not by guesswork.</p>
    <div id="unknown"></div>
  </section>

  <section>
    <h2>Leadership by shift</h2>
    <p class="hint">Tracked separately — not counted in the agent adoption figures.</p>
    <div id="leaders"></div>
  </section>

  <section>
    <h2>Officers</h2>
    <p class="hint">Quality control and L&amp;D. Also excluded from agent adoption.</p>
    <div id="qa"></div>
  </section>
</div>

<script>
const ROSTER = {"723": ["Mahmoud Hussien", "M", "", 1, "TL"], "449": ["Mina Atef", "M", "", 1, "DTL"], "1233": ["Mohamed Hossam", "M", "", 1, "SME"], "1322": ["Mohamed Tarek", "M", "", 1, "SME"], "1562": ["Reem Rajab", "M", "", 1, "SME"], "424": ["Marco Gamil", "M", "Hossam", 0, "Agent"], "430": ["Amr Ahmed", "M", "Hossam", 0, "Agent"], "441": ["Fathelrahman Youssif", "M", "Hossam", 0, "Agent"], "728": ["Mohamed Amir", "M", "Hossam", 0, "Agent"], "731": ["Mohamed Taher", "M", "Hossam", 0, "Agent"], "747": ["Marina Boules", "M", "Tarek", 0, "Agent"], "813": ["Mohamed Khaled", "M", "Hossam", 0, "Agent"], "822": ["Mennatalla Mohamed", "M", "Hossam", 0, "Agent"], "989": ["Reem Mohamed", "M", "Tarek", 0, "Agent"], "1070": ["Sumaia Sharafeldin", "M", "Reem", 0, "Agent"], "1198": ["Yahia Tamer", "M", "Tarek", 0, "Agent"], "1221": ["Mohamed Ahmed", "M", "Tarek", 0, "Agent"], "1286": ["Mahmoud Sayed", "M", "Tarek", 0, "Agent"], "1320": ["Hussein Refaee", "M", "Tarek", 0, "Agent"], "1346": ["Merolla Amir", "M", "Reem", 0, "Agent"], "1530": ["Eman Haggag", "M", "Hossam", 0, "Agent"], "1532": ["Nagham Islam", "M", "Tarek", 0, "Agent"], "1534": ["Rawan Magdy", "M", "Tarek", 0, "Agent"], "1542": ["Sahar Salah", "M", "Tarek", 0, "Agent"], "1543": ["Sarra Abdelrasoul", "M", "Reem", 0, "Agent"], "1555": ["Reem Abdelhafeez", "M", "Reem", 0, "Agent"], "1561": ["Nada Hossam", "M", "Hossam", 0, "Agent"], "1564": ["Omima Nabil", "M", "Hossam", 0, "Agent"], "1622": ["Salma Sami", "M", "Hossam", 0, "Agent"], "2297": ["Jana Amr", "M", "Tarek", 0, "Agent"], "2298": ["Noura Mohamed", "M", "Hossam", 0, "Agent"], "2299": ["Reem Gamal", "M", "Tarek", 0, "Agent"], "2300": ["Ahd Gameel", "M", "Reem", 0, "Agent"], "2301": ["Rawan Mohey", "M", "Hossam", 0, "Agent"], "2302": ["Nourhan Ahmed", "M", "Reem", 0, "Agent"], "2303": ["Farah Sherif", "M", "", 3, "Left"], "2304": ["Nada Ramadan", "M", "", 3, "Left"], "2324": ["Reham Rushdy", "M", "Reem", 0, "Agent"], "2325": ["Mina Ehab", "M", "Reem", 0, "Agent"], "2326": ["Rawan Ibrahim", "M", "Reem", 0, "Agent"], "2327": ["Menna Badawy", "M", "Hossam", 0, "Agent"], "2328": ["Maria Mounir", "M", "Tarek", 0, "Agent"], "2329": ["Fares Amir", "M", "Reem", 0, "Agent"], "2330": ["Mayar Hesham", "M", "Reem", 0, "Agent"], "2331": ["Ismail Hesham", "M", "Reem", 0, "Agent"], "2333": ["El Amira", "M", "Hossam", 0, "Agent"], "2334": ["Merdeen Mohamed", "M", "Tarek", 0, "Agent"], "2335": ["Ghaidaa Alaa", "M", "Hossam", 0, "Agent"], "2336": ["Rawan Mohamed", "M", "Reem", 0, "Agent"], "2337": ["Hamza Mohamed", "M", "Tarek", 0, "Agent"], "2405": ["Maria Mikhail", "M", "Reem", 0, "Agent"], "2406": ["Salma Mohamed", "M", "Reem", 0, "Agent"], "2407": ["Salma Khalil", "M", "Reem", 0, "Agent"], "2408": ["Noha Araby", "M", "Tarek", 0, "Agent"], "2409": ["Mirette Medhat", "M", "Tarek", 0, "Agent"], "2410": ["Ganna Bassam", "M", "", 3, "Left"], "2411": ["Verina Philps", "M", "Reem", 0, "Agent"], "2412": ["Dareen Mohamed", "M", "Tarek", 0, "Agent"], "2413": ["Marina Saad", "M", "Reem", 0, "Agent"], "139": ["AbdelRahman Mostafa", "A", "", 1, "Account Manager"], "10": ["Omar Asem", "A", "", 1, "TL"], "674": ["Omar Abobakr", "A", "", 1, "DTL"], "508": ["Raheem Abdelmaksoud", "A", "", 1, "SME"], "1096": ["Kirrolos Safwat", "A", "", 1, "SME"], "1325": ["Manar Mahdy", "A", "", 1, "SME"], "849": ["Aya Tarig", "A", "Kirolos", 0, "Accuracy Team"], "1027": ["Omar Abdel", "A", "Kirolos", 0, "Accuracy Team"], "1128": ["Rahaf Khalid", "A", "Kirolos", 0, "Accuracy Team"], "1230": ["AbdeRahman Aamer", "A", "", 1, "Data Analyst"], "1231": ["Muhammed Said", "A", "", 1, "Data Analyst"], "388": ["Ehab Ahmed", "A", "Raheem", 0, "Agent"], "730": ["Mohamed Ahmed", "A", "Kirolos", 0, "Agent"], "1081": ["Rawan Esameldin", "A", "Raheem", 0, "Agent"], "1083": ["Sandra Nabil", "A", "Kirolos", 0, "Agent"], "1222": ["Tamim Abdelrahman", "A", "Raheem", 0, "Agent"], "1301": ["Salma Mohamed", "A", "Raheem", 0, "Agent"], "1302": ["Ali Ramadan", "A", "Raheem", 0, "Agent"], "1318": ["Sandy Fahmy", "A", "Raheem", 0, "Agent"], "1535": ["Aisha Mohammed", "A", "Raheem", 0, "Agent"], "1537": ["Mohamed Mamdouh", "A", "", 3, "Left"], "1549": ["Abdulrahman Ahmed", "A", "", 3, "Left"], "1565": ["Mahmoud Mohamed", "A", "Kirolos", 0, "Agent"], "1614": ["Ahmed Hussien", "A", "", 3, "Left"], "1616": ["Afaf Khaled", "A", "Manar", 0, "Agent"], "1617": ["Yassmine Amr", "A", "Manar", 0, "Agent"], "1618": ["Ahmed Reda", "A", "Manar", 0, "Agent"], "1619": ["ibrahim ashraf", "A", "Manar", 0, "Agent"], "1620": ["Marwa Ismail", "A", "Raheem", 0, "Agent"], "1621": ["Shahd Ahmed", "A", "Kirolos", 0, "Agent"], "1623": ["Wafaa Mohamed", "M", "Tarek", 0, "Agent"], "1841": ["Salah Ali", "A", "Raheem", 0, "Agent"], "1876": ["Mohamed Montasir", "A", "Raheem", 0, "Agent"], "1882": ["Aliaa Mohammed", "A", "Manar", 0, "Agent"], "1883": ["Ziad Walid", "A", "Manar", 0, "Agent"], "1884": ["Hassan Mahmoud", "A", "Manar", 0, "Agent"], "1885": ["Mohamed Ashraf", "A", "Raheem", 0, "Agent"], "1886": ["Ibrahim Ahmed", "A", "Kirolos", 0, "Agent"], "1888": ["Abeer Salem", "A", "Manar", 0, "Agent"], "1890": ["Mohammed Osama", "A", "Raheem", 0, "Agent"], "1891": ["Dalia Osama", "A", "Kirolos", 0, "Agent"], "1894": ["Karim Hemdan", "A", "Kirolos", 0, "Agent"], "2224": ["Omnia Essam", "A", "Raheem", 0, "Agent"], "2225": ["Ahmed Nasser", "A", "Kirolos", 0, "Agent"], "2226": ["Nour El", "A", "Kirolos", 0, "Agent"], "507": ["Mohamed Ibrahim", "N", "", 1, "DTL"], "444": ["Kareem Mohamed", "N", "", 1, "SME"], "1163": ["Rodaina Ashraf", "N", "", 1, "SME"], "1263": ["Omar Ahmed", "N", "", 1, "SME"], "506": ["Tarek Ahmed", "N", "Karim", 0, "Agent"], "1145": ["Mohamed Hesham", "N", "Rabiea", 0, "Agent"], "1194": ["Ahmed Abdelaziz", "N", "Karim", 0, "Agent"], "1204": ["Ahmed Mostafa", "N", "Rodaina", 0, "Agent"], "1248": ["Abdallh Sami", "A", "Raheem", 0, "Agent"], "1285": ["Mohamed yasser", "N", "Rodaina", 0, "Agent"], "1321": ["Omar Abdelfattah", "N", "Rodaina", 0, "Agent"], "1349": ["Omar Khaled", "N", "Karim", 0, "Agent"], "1615": ["May Lateef", "N", "Rabiea", 0, "Agent"], "1739": ["Ahmed Wagdy", "A", "Manar", 0, "Agent"], "1776": ["AbdelRahman Gamal", "N", "Karim", 0, "Agent"], "1777": ["Ahmed Lotfy", "N", "", 3, "Left"], "1832": ["Fathy Hazem", "N", "Rabiea", 0, "Agent"], "1833": ["Reham Ibrahim", "N", "Karim", 0, "Agent"], "1837": ["Ahmed Mohamed", "N", "Karim", 0, "Agent"], "1838": ["Hazem Karam", "N", "Rodaina", 0, "Agent"], "1839": ["Faten Alaa", "N", "Karim", 0, "Agent"], "1840": ["Adham Essam", "A", "Manar", 0, "Agent"], "2228": ["Fares Ali", "N", "Rodaina", 0, "Agent"], "2229": ["Mariam Nasr", "N", "Rodaina", 0, "Agent"], "2230": ["Fady Nasr", "N", "Karim", 0, "Agent"], "2231": ["Kenzie Waleed", "N", "Karim", 0, "Agent"], "2292": ["Ahmed Tarek", "N", "Rabiea", 0, "Agent"], "2293": ["Abdelrahman Gamal", "N", "Rabiea", 0, "Agent"], "2294": ["Mostafa Gamal", "N", "Rabiea", 0, "Agent"], "2295": ["Mariam Samir", "A", "Manar", 0, "Agent"], "2318": ["Kerlos Medhat", "N", "", 3, "Left"], "2319": ["Ahmed Mohamed", "N", "Rodaina", 0, "Agent"], "2321": ["Fouad Mahmoud", "N", "Rabiea", 0, "Agent"], "2322": ["Asmaa Mohamed", "N", "Rabiea", 0, "Agent"], "2323": ["Mohamed Rezk", "N", "Rodaina", 0, "Agent"], "2414": ["Mohamed Tayeb", "N", "Rodaina", 0, "Agent"], "2415": ["Mohamed Atef", "N", "Rabiea", 0, "Agent"], "2416": ["Samir Abdelhameed", "N", "Rabiea", 0, "Agent"], "2417": ["Omar Abdelnaser", "N", "Rodaina", 0, "Agent"], "2418": ["Ahmed Samy", "N", "Rabiea", 0, "Agent"], "2419": ["Amir Maher", "N", "Rabiea", 0, "Agent"], "2420": ["Asser Khaled", "N", "Karim", 0, "Agent"], "2421": ["Shenouda El", "N", "Rodaina", 0, "Agent"], "2422": ["Youssif Mohamed", "N", "Rodaina", 0, "Agent"], "2423": ["Mohamed El", "N", "Karim", 0, "Agent"], "2424": ["Adham Hassan", "N", "Karim", 0, "Agent"], "675": ["Abdallah Ahmed", "O", "", 2, "QC Officer"], "1224": ["Mahitab Mostafa", "O", "", 2, "QC Officer"], "1519": ["Youssef Mohamed", "O", "", 2, "QC Officer"], "1541": ["Alyaa Sherif", "O", "", 2, "QC Officer"], "991": ["Ahmed Ibrahim", "M", "Tarek", 0, "Agent"], "2457": ["Youssef Khaled", "N", "", 3, "Left"], "2458": ["Mahmoud Ebhas", "N", "Karim", 0, "Agent"], "2460": ["Emam Yasser", "N", "Rodaina", 0, "Agent"], "2461": ["Mahmoud Gamal", "N", "Rabiea", 0, "Agent"], "2462": ["Salma Mohamed", "N", "Rodaina", 0, "Agent"], "2463": ["Andrew Basem", "N", "Karim", 0, "Agent"], "2465": ["Ahmed Adel", "N", "Karim", 0, "Agent"], "2466": ["Yassmin Mohamed", "M", "Hossam", 0, "Agent"], "2467": ["Abdulllah Alaa", "M", "Hossam", 0, "Agent"], "2468": ["Sarah Ibrahim", "M", "Hossam", 0, "Agent"], "2469": ["Reem Abdelnasser", "M", "", 3, "Left"], "1197": ["Eslam Fahd", "O", "", 2, "L&D Officer"], "1136": ["Ahmed Khaled", "A", "", 3, "Left"], "1924": ["Rozan Adel", "A", "", 3, "Left"], "1156": ["Mohamed Abdelhamid", "N", "", 3, "Left"], "1834": ["Menna Ahmed", "N", "", 3, "Left"], "1835": ["Marwa Ali", "N", "", 3, "Left"], "1836": ["Ziad Nasser", "N", "", 3, "Left"], "1889": ["Mohamed Ali", "N", "", 3, "Left"], "1311": ["Mennatullah Elhoriny", "M", "", 3, "Left"], "1566": ["Omar Anas", "M", "", 3, "Left"], "2320": ["Hossam Khaled", "N", "", 3, "Left"], "2498": ["Ahmed Shaban", "N", "Karim", 0, "Agent"], "2499": ["Zeyad Mohamed", "N", "Rabiea", 0, "Agent"], "2500": ["Motasem Abdullah", "N", "Rodaina", 0, "Agent"], "2501": ["Abdelrahman Omar", "N", "Rodaina", 0, "Agent"], "2503": ["Mustafa Samy", "N", "Karim", 0, "Agent"], "2504": ["Ahmed Sherif", "N", "Rabiea", 0, "Agent"], "2505": ["Ziad Gamal", "N", "Karim", 0, "Agent"], "2506": ["Abdelrahman Hossam", "N", "Rodaina", 0, "Agent"], "2507": ["Khaled Mohsen", "N", "Rabiea", 0, "Agent"], "2534": ["Yasser Fathy", "N", "Rodaina", 0, "Agent"], "2535": ["Zeyad Akef", "N", "Rabiea", 0, "Agent"], "2536": ["Hisham Mohamed", "N", "Karim", 0, "Agent"], "2537": ["Mohammed Khalaf", "N", "Rodaina", 0, "Agent"], "2538": ["Mohammed Ahmed", "N", "Rabiea", 0, "Agent"], "2539": ["Youmna Zayed", "M", "Tarek", 0, "Agent"], "2540": ["Nada Mostafa", "M", "Reem", 0, "Agent"], "2541": ["Rana Shaker", "M", "Tarek", 0, "Agent"], "2543": ["Farah Ibrahim", "M", "Hossam", 0, "Agent"]};
const LAUNCH = '2026-08-18';
/* v128: the tool has SIX tabs. switchTab() beacons 'careplan' for the Problem
   Note Generator, but this map only ever had five entries — so that tab showed
   up as the raw key "careplan" in the usage bars and was missing outright from
   the daily per-agent grid, whose column list was hardcoded to the same five.
   Keys here must match switchTab()'s tab ids in index.html exactly. */
const TABNAME = {"reference": "Reference", "analyzer": "Med Analyzer", "prognotes": "Progress Notes", "loinc": "LOINC Codes", "templates": "Templates", "careplan": "Problem Note Generator"};
/* The daily grid's columns, in the tool's own tab order. Derived from TABNAME so
   a seventh tab can never again be counted in the totals but missing here. */
const TAB_COLS = Object.keys(TABNAME);
/* 'O' = no clock shift: the QC officers (filed under a pseudo-shift "QC" in
   the roster sheet) and, from v126, the L&D officer. */
const SHIFT = {M:'Morning',A:'Afternoon',N:'Night',O:'Officers'};
/* v127: the scheduled hours each shift actually works, from the team sheet. */
const SHIFT_TIME = {"M": "7 AM - 4 PM", "A": "4 PM - 1 AM", "N": "1 AM - 10 AM", "O": ""};
/* The delegate teams. label -> [SME short name, SME code, shift letter].
   v128: this and ROSTER are generated from roster_source.json, which is
   exported straight out of CCM_Brightwell_Roster.xlsx — so the workbook is the
   single source of truth and the release suite reconciles all three. v127 built
   them from a transcription of the team screenshots instead; the rebuild
   reproduced every row identically, which is what proved the two agreed. */
const TEAMS = {"Hossam": ["Mohamed Hossam", "1233", "M"], "Reem": ["Reem Rajab", "1562", "M"], "Tarek": ["Mohamed Tarek", "1322", "M"], "Kirolos": ["Kirrolos Safwat", "1096", "A"], "Manar": ["Manar Mahdy", "1325", "A"], "Raheem": ["Raheem Abdelmaksoud", "508", "A"], "Karim": ["Kareem Mohamed", "444", "N"], "Rabiea": ["Omar Ahmed", "1263", "N"], "Rodaina": ["Rodaina Ashraf", "1163", "N"]};
const SHIFT_ORDER = {M:0,A:1,N:2,O:3};
const esc = s => String(s).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
const ymd = d => d.toISOString().slice(0,10);

document.getElementById('go').onclick = load;
document.getElementById('tok').addEventListener('keydown',e=>{if(e.key==='Enter')load();});
try{const t=sessionStorage.getItem('ccm_stats_tok'); if(t){document.getElementById('tok').value=t; load();}}catch(e){}

/* The selected range. Every figure on this page is computed over it. The
   request also asks for the SAME NUMBER OF DAYS immediately before it, so
   "vs previous period" is a real comparison rather than a fixed week — but only
   when both halves fit inside the API's span cap. When they do not, the
   comparison is left blank rather than quietly measured against a shorter one. */
const MAX_SPAN = 92;
const RANGE = { from:'', to:'' };
const dayMs = 864e5;
const parseDay = s => new Date(s + 'T00:00:00Z');
const addDays = (s, n) => ymd(new Date(parseDay(s).getTime() + n * dayMs));
const spanOf = (a, b) => Math.round((parseDay(b) - parseDay(a)) / dayMs) + 1;
const listDays = (from, to) => { const a=[];
  for(let t=parseDay(from).getTime(); t<=parseDay(to).getTime(); t+=dayMs) a.push(ymd(new Date(t)));
  return a; };

function setRange(from, to){
  RANGE.from = from; RANGE.to = to;
  const f=document.getElementById('fFrom'), t=document.getElementById('fTo');
  if(f) f.value = from;
  if(t) t.value = to;
}
function defaultRange(days){
  const to = ymd(new Date());
  return [addDays(to, -(days - 1)), to];
}

async function load(){
  const tok=document.getElementById('tok').value.trim(), err=document.getElementById('err');
  if(!tok){ err.textContent='Enter the token to continue.'; return; }
  err.textContent='Loading...';
  if(!RANGE.from) setRange.apply(null, defaultRange(30));

  const span = Math.max(1, Math.min(spanOf(RANGE.from, RANGE.to), MAX_SPAN));
  const withPrev = span * 2 <= MAX_SPAN;
  const fetchFrom = withPrev ? addDays(RANGE.from, -span) : RANGE.from;

  const app=document.getElementById('app');
  if(app) app.classList.add('busy');
  try{
    const r=await fetch('/api/stats?from='+encodeURIComponent(fetchFrom)
                        +'&to='+encodeURIComponent(RANGE.to)
                        +'&token='+encodeURIComponent(tok));
    if(r.status===401){ err.textContent='That token was not accepted.'; return; }
    if(!r.ok){
      /* v150: the server's own reason, not just the status. */
      let why='';
      try{ const j=await r.json(); why=String(j.detail||j.error||''); }catch(e){}
      const lim=/limit|quota|exceeded|too many/i.test(why);
      err.textContent='Server returned '+r.status+(why?' \\u2014 '+why:'')+'.'
        +(lim?' This is Cloudflare\\u2019s daily limit on the storage account; it resets at 00:00 UTC.':'');
      return;
    }
    const d=await r.json();
    d._span=span; d._withPrev=withPrev;
    try{ sessionStorage.setItem('ccm_stats_tok',tok); }catch(e){}
    err.textContent='';
    document.getElementById('gate').style.display='none';
    document.getElementById('app').style.display='';
    /* Outside the fetch's catch on purpose. A thrown render() used to be
       reported as "Could not reach the server", which hid a real page bug
       behind a network message. */
    setTimeout(function(){ render(d); }, 0);
  }catch(e){ err.textContent='Could not reach the server.'; }
  finally{ if(app) app.classList.remove('busy'); }
}

/* Presets first, custom range behind them - the order people reach for. */
function wireFilters(){
  const btns=[].slice.call(document.querySelectorAll('.preset[data-days],.preset[data-mtd],.preset[data-lastmonth]'));
  const mark=(el)=>btns.forEach(b=>b.setAttribute('aria-pressed', String(b===el)));
  btns.forEach(b=>{
    b.onclick=()=>{
      const now=new Date();
      if(b.dataset.days){ setRange.apply(null, defaultRange(+b.dataset.days)); }
      else if(b.dataset.mtd){
        setRange(ymd(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1))), ymd(now));
      } else {
        setRange(ymd(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth()-1, 1))),
                 ymd(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 0))));
      }
      mark(b); load();
    };
  });
  const apply=document.getElementById('fApply');
  if(apply) apply.onclick=()=>{
    const f=document.getElementById('fFrom').value, t=document.getElementById('fTo').value;
    if(!f||!t) return;
    setRange(f<t?f:t, f<t?t:f); mark(null); load();
  };
  const def=btns.filter(b=>b.dataset.days==='30')[0];
  if(def) def.setAttribute('aria-pressed','true');
}
wireFilters();
setRange.apply(null, defaultRange(30));


/* v77: /api/stats now returns bare agent codes (the name is resolved here from
   ROSTER). Older responses returned "Name (code)" — both are accepted. */
const codeOf = s => {
  const t = String(s).trim();
  if (/^\\d+$/.test(t)) return t;
  return (t.match(/\\((\\d+)\\)\\s*$/) || [])[1] || null;
};

/* ====================================================================
   Charts. Inline SVG, no libraries — this page is served as a single
   string from _worker.js and must stay self-contained.
   One hue (--deep) carries every mark; amber is a status, not a series.
   ==================================================================== */
const VIZ = { mark:'#0f766e', soft:'rgba(15,118,110,.14)', flag:'#b45309',
              grid:'#eef3f2', axis:'#dfe8e5', mut:'#7c9691', ink:'#0b1f1c' };

const svgEl = (name, attrs) => {
  const e = document.createElementNS('http://www.w3.org/2000/svg', name);
  for (const k in attrs) if (attrs[k] !== null && attrs[k] !== undefined)
    e.setAttribute(k, String(attrs[k]));
  return e;
};
const svgRoot = (w, h) => {
  const s = svgEl('svg', { viewBox: '0 0 ' + w + ' ' + h, role: 'img' });
  s.style.width = '100%'; s.style.height = 'auto';
  return s;
};
const txt = (x, y, s, o) => {
  o = o || {};
  const t = svgEl('text', { x: x, y: y, fill: o.fill || VIZ.mut,
    'font-size': o.size || 10.5, 'text-anchor': o.anchor || 'start',
    'font-weight': o.weight || 400,
    'font-family': 'system-ui,-apple-system,Segoe UI,sans-serif' });
  if (o.tabular) t.setAttribute('style', 'font-variant-numeric:tabular-nums');
  t.textContent = s;
  return t;
};
/* Ticks a person would choose: 1, 2, 5, 10, 20, 50 ... */
function niceTicks(max, count){
  if (max <= 0) return [0, 1];
  const raw = max / (count || 4);
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const step = [1, 2, 2.5, 5, 10].map(m => m * mag).filter(s => s >= raw)[0] || 10 * mag;
  const out = [0];
  /* Keep going until the top tick is at or above the peak — stopping at the
     last tick <= max puts the scale's ceiling BELOW the data and every mark
     drawn against it overflows the plot. */
  while (out[out.length - 1] < max - 1e-9)
    out.push(Math.round((out[out.length - 1] + step) * 100) / 100);
  return out;
}

/* One shared tooltip. Hit targets are wider than the marks. */
const TIP = () => document.getElementById('tip');
function tipShow(ev, html){
  const t = TIP(); if (!t) return;
  t.innerHTML = html; t.classList.add('on');
  const pad = 12, w = t.offsetWidth, h = t.offsetHeight;
  let x = ev.clientX + pad, y = ev.clientY - h - pad;
  if (x + w > window.innerWidth - 8) x = ev.clientX - w - pad;
  if (y < 8) y = ev.clientY + pad;
  t.style.left = x + 'px'; t.style.top = y + 'px';
}
function tipHide(){ const t = TIP(); if (t) t.classList.remove('on'); }
function hoverable(el, html){
  el.addEventListener('mousemove', e => tipShow(e, html));
  el.addEventListener('mouseleave', tipHide);
}

function mountChart(id, node){
  const host = document.getElementById(id);
  if (!host) return;
  host.innerHTML = '';
  host.appendChild(node);
}
function emptyNote(id, msg){
  const host = document.getElementById(id);
  if (host) host.innerHTML = '<div class="empty">' + esc(msg) + '</div>';
}

/* ── 1. Agents using the tool each day ─────────────────────────────────
   Trend over time, one series: area + line, with a crosshair. */
function drawDaily(days, counts, total){
  const sub = document.getElementById('cDailySub');
  if (!days.length) { emptyNote('cDaily', 'No days in this range.'); return; }
  const peak = Math.max.apply(null, counts), any = counts.some(n => n > 0);
  const avg = counts.reduce((a, b) => a + b, 0) / counts.length;
  if (sub) sub.textContent = any
    ? 'Peak ' + peak + ' of ' + total + ' · average ' + avg.toFixed(1) + ' a day'
    : 'No agent opened the tool in this range.';
  if (!any) { emptyNote('cDaily', 'No activity recorded in this range.'); return; }

  const W = 920, H = 230, L = 34, R = 10, T = 12, B = 26;
  const iw = W - L - R, ih = H - T - B;
  const ticks = niceTicks(peak, 4), top = ticks[ticks.length - 1];
  const x = i => L + (days.length === 1 ? iw / 2 : i * iw / (days.length - 1));
  const y = v => T + ih - (v / top) * ih;

  const s = svgRoot(W, H);
  s.appendChild(svgEl('title', {})).textContent =
    'Agents using the tool each day, ' + days[0] + ' to ' + days[days.length - 1];

  ticks.forEach(v => {
    s.appendChild(svgEl('line', { x1: L, x2: W - R, y1: y(v), y2: y(v),
      stroke: v === 0 ? VIZ.axis : VIZ.grid, 'stroke-width': 1 }));
    s.appendChild(txt(L - 7, y(v) + 3.5, String(v), { anchor: 'end', tabular: 1 }));
  });

  const pts = counts.map((v, i) => x(i) + ',' + y(v)).join(' ');
  s.appendChild(svgEl('polygon', {
    points: L + ',' + y(0) + ' ' + pts + ' ' + x(days.length - 1) + ',' + y(0),
    fill: VIZ.soft }));
  s.appendChild(svgEl('polyline', { points: pts, fill: 'none', stroke: VIZ.mark,
    'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));

  /* x labels: about six, never overlapping */
  const every = Math.max(1, Math.ceil(days.length / 6));
  days.forEach((dy, i) => {
    if (i % every && i !== days.length - 1) return;
    s.appendChild(txt(x(i), H - 8, dy.slice(5), { anchor: 'middle', tabular: 1 }));
  });

  /* crosshair: one hit column per day, wider than the mark */
  const rule = svgEl('line', { y1: T, y2: T + ih, stroke: VIZ.mark,
    'stroke-width': 1, opacity: 0 });
  /* Parked ON the plot, not at the origin: a circle left at (0,0) sits outside
     the viewBox and drags the drawing's bounds out with it. */
  const dot = svgEl('circle', { r: 4.5, cx: L, cy: y(0), fill: VIZ.mark,
    stroke: '#fff', 'stroke-width': 2, opacity: 0 });
  s.appendChild(rule); s.appendChild(dot);
  const cw = iw / Math.max(1, days.length);
  days.forEach((dy, i) => {
    const hit = svgEl('rect', { x: x(i) - cw / 2, y: T, width: cw, height: ih,
      fill: 'transparent' });
    hit.addEventListener('mousemove', e => {
      rule.setAttribute('x1', x(i)); rule.setAttribute('x2', x(i));
      rule.setAttribute('opacity', 1);
      dot.setAttribute('cx', x(i)); dot.setAttribute('cy', y(counts[i]));
      dot.setAttribute('opacity', 1);
      tipShow(e, '<b>' + counts[i] + '</b> of ' + total + ' agents<br>' + dy);
    });
    hit.addEventListener('mouseleave', () => {
      rule.setAttribute('opacity', 0); dot.setAttribute('opacity', 0); tipHide();
    });
    s.appendChild(hit);
  });
  mountChart('cDaily', s);
}

/* ── 2. Adoption by team ───────────────────────────────────────────────
   Magnitude across nominal categories: horizontal bars, ONE hue, every bar
   direct-labelled. A team nobody used is amber AND says so in words. */
/* v134: every group a counted agent actually belongs to, not just the ones
   with an SME. Nine new Night hires have no Delegate in the sheet yet; before
   this they would have been inside the adoption denominator but absent from
   the chart that breaks it down, which is how a whole group goes unnoticed.
   Deriving the list means a second one can never drift from the first. */
function boardGroups(){
  const g = {};
  Object.keys(TEAMS).forEach(k => { g[k] = true; });
  Object.keys(ROSTER).forEach(c => {
    if (ROSTER[c][3] === 0 && ROSTER[c][2]) g[ROSTER[c][2]] = true;
  });
  return Object.keys(g);
}
function drawTeams(cur){
  const labels = boardGroups();
  if (!labels.length) { emptyNote('cTeams', 'No teams defined.'); return; }
  const rows = labels.map(k => {
    const list = Object.keys(ROSTER).filter(c => ROSTER[c][3] === 0 && ROSTER[c][2] === k);
    const used = list.filter(c => cur[c]).length;
    const t = TEAMS[k];
    return { k: k, sme: t ? t[0] : 'no delegate assigned yet',
             shift: t ? (SHIFT[t[2]] || '') : '', n: list.length,
             used: used, pct: list.length ? used / list.length : 0 };
  }).sort((a, b) => b.pct - a.pct || a.k.localeCompare(b.k));

  const RH = 27, W = 440, L = 86, R = 54, T = 6;
  const H = T + rows.length * RH + 6, iw = W - L - R;
  const s = svgRoot(W, H);
  s.appendChild(svgEl('title', {})).textContent = 'Share of each team active in the range';

  rows.forEach((r, i) => {
    const yc = T + i * RH, bh = 11, by = yc + 7;
    const zero = r.used === 0;
    const col = zero ? VIZ.flag : VIZ.mark;
    s.appendChild(txt(L - 8, by + bh - 1.5, r.k, { anchor: 'end', fill: VIZ.ink, weight: 600 }));
    s.appendChild(svgEl('rect', { x: L, y: by, width: iw, height: bh, rx: 4, fill: VIZ.grid }));
    const w = Math.max(zero ? 0 : 3, Math.round(r.pct * iw));
    if (w > 0) s.appendChild(svgEl('rect', { x: L, y: by, width: w, height: bh, rx: 4, fill: col }));
    s.appendChild(txt(L + iw + 7, by + bh - 1.5,
      zero ? 'none' : (r.used + '/' + r.n + '  ' + Math.round(r.pct * 100) + '%'),
      { fill: zero ? VIZ.flag : VIZ.ink, weight: zero ? 600 : 400, tabular: 1 }));
    const hit = svgEl('rect', { x: 0, y: yc, width: W, height: RH, fill: 'transparent' });
    hoverable(hit, '<b>' + esc(r.k) + '</b> — ' + esc(r.sme) + '<br>'
      + (r.shift ? esc(r.shift) + ' · ' : '')
      + r.used + ' of ' + r.n + ' agents active');
    s.appendChild(hit);
  });
  mountChart('cTeams', s);
}

/* ── 3. How often agents come back ─────────────────────────────────────
   Ordered buckets, one series: columns, one hue. The "never" bucket is the
   one that needs acting on, so it carries the status colour and its label. */
function drawDepth(agents, cur, span){
  const edges = [[0, 0, 'never'], [1, 2, '1-2 days'], [3, 5, '3-5 days'],
                 [6, 10, '6-10 days'], [11, 1e9, '11+ days']];
  const buckets = edges.map(e => ({ lo: e[0], hi: e[1], label: e[2], n: 0 }));
  agents.forEach(([c]) => {
    const n = cur[c] || 0;
    const b = buckets.filter(b => n >= b.lo && n <= b.hi)[0];
    if (b) b.n++;
  });
  const peak = Math.max.apply(null, buckets.map(b => b.n));
  const sub = document.getElementById('cDepthSub');
  if (sub) sub.textContent = 'Agents grouped by how many of the ' + span
    + ' days in range they used the tool.';
  if (!peak) { emptyNote('cDepth', 'No agents to group.'); return; }

  const W = 440, H = 210, L = 30, R = 8, T = 16, B = 34;
  const iw = W - L - R, ih = H - T - B;
  const ticks = niceTicks(peak, 3), top = ticks[ticks.length - 1];
  const y = v => T + ih - (v / top) * ih;
  const bw = iw / buckets.length;
  const s = svgRoot(W, H);
  s.appendChild(svgEl('title', {})).textContent = 'Agents grouped by days of use in the range';

  ticks.forEach(v => {
    s.appendChild(svgEl('line', { x1: L, x2: W - R, y1: y(v), y2: y(v),
      stroke: v === 0 ? VIZ.axis : VIZ.grid, 'stroke-width': 1 }));
    s.appendChild(txt(L - 7, y(v) + 3.5, String(v), { anchor: 'end', tabular: 1 }));
  });

  buckets.forEach((b, i) => {
    const zero = b.lo === 0;
    const x = L + i * bw + bw * 0.18, w = bw * 0.64;
    const h = b.n ? Math.max(2, Math.round((b.n / top) * ih)) : 0;
    if (h) s.appendChild(svgEl('rect', { x: x, y: y(b.n), width: w, height: h, rx: 4,
      fill: zero ? VIZ.flag : VIZ.mark }));
    s.appendChild(txt(x + w / 2, y(b.n) - 5, String(b.n),
      { anchor: 'middle', fill: zero ? VIZ.flag : VIZ.ink, weight: 600, tabular: 1 }));
    s.appendChild(txt(x + w / 2, H - 18, b.label, { anchor: 'middle' }));
    const hit = svgEl('rect', { x: L + i * bw, y: T, width: bw, height: ih + 14,
      fill: 'transparent' });
    hoverable(hit, '<b>' + b.n + '</b> agent(s)<br>used the tool ' + esc(b.label)
      + ' of ' + span);
    s.appendChild(hit);
  });
  mountChart('cDepth', s);
}

function render(d){
  const days=[...(d.days||[])].sort((a,b)=>a.day.localeCompare(b.day));
  const byDay={}; days.forEach(x=>byDay[x.day]=new Set((x.agents||[]).map(codeOf).filter(Boolean)));

  const today=new Date();
  /* The window is whatever the filter says; the comparison window is the same
     number of days immediately before it. A 7-day view and a 90-day view are
     then the same computation with different bounds. */
  const span = d._span || spanOf(RANGE.from, RANGE.to);
  const curDays  = listDays(RANGE.from, RANGE.to);
  const prevDays = d._withPrev ? listDays(addDays(RANGE.from,-span), addDays(RANGE.from,-1)) : [];
  const usedIn=w=>{const m={};w.forEach(dy=>(byDay[dy]||new Set()).forEach(c=>m[c]=(m[c]||0)+1));return m;};
  const cur=usedIn(curDays), prev=usedIn(prevDays);

  /* Each ROSTER row is [shortName, shiftLetter, boardGroup, roleBucket, roleTitle].
     roleBucket: 0 agent · 1 leadership · 2 officer (QC / L&D) · 3 left.
     Only bucket 0 counts toward agent adoption. People who have left stay in the
     roster so historical activity still resolves to a name instead of "Unknown",
     but they are excluded from every current figure and follow-up list.
     v126: regenerated from the shipped tool roster plus the canonical Brightwell
     roster sheet. The previous list was a v77-era snapshot of 104 people whose
     agent denominator had drifted to 87 while 133 people could sign in — so every
     adoption percentage this dashboard printed was computed against the wrong
     total, and staff who had left were still being counted as active. roleTitle
     (element 4) now carries the real role from the roster sheet rather than being
     inferred from the bucket. */
  const agents  = Object.entries(ROSTER).filter(([,v])=>v[3]===0);
  const leaders = Object.entries(ROSTER).filter(([,v])=>v[3]===1);
  const qa      = Object.entries(ROSTER).filter(([,v])=>v[3]===2);
  const nCur=agents.filter(([c])=>cur[c]).length, nPrev=agents.filter(([c])=>prev[c]).length;
  const delta=nCur-nPrev;

  const tb=(d.totals&&d.totals.tabs)||{};
  const tabTotal=Object.values(tb).reduce((a,b)=>a+b,0);
  const anaShare=tabTotal?Math.round((tb.analyzer||0)/tabTotal*100):null;
  const since=Math.max(0,Math.round((today-new Date(LAUNCH))/864e5));

  /* v126: state the roster's provenance on the page. The old list had drifted
     49 builds behind the tool without anything on screen saying so. */
  const rsEl=document.getElementById('rosterStamp');
  if(rsEl) rsEl.textContent='roster: v148 \\u00b7 '+agents.length+' agents \\u00b7 '
    +boardGroups().length+' teams \\u00b7 '+leaders.length+' leadership \\u00b7 '
    +qa.length+' officers';

  document.getElementById('period').textContent =
    RANGE.from+'  \\u2192  '+RANGE.to+'  \\u00b7  '+span+' days';
  const fnote=document.getElementById('fNote');
  if(fnote) fnote.textContent = (d.range && d.range.maxSpan)
    ? 'up to '+d.range.maxSpan+' days per view' : '';

  document.getElementById('kpis').innerHTML=[
    ['<span class="n">'+nCur+'</span>','agents in range','of '+agents.length+' \\u00b7 '+Math.round(nCur/agents.length*100)+'%'],
    [(!d._withPrev || delta===0)
       ? '<span class="n flat">\\u2014</span>'
       : '<span class="n '+(delta>0?'up':'down')+'">'+(delta>0?'+':'')+delta+'</span>',
     'vs previous '+span+' days',
     d._withPrev ? nPrev+' agent(s) in the '+span+' days before'
                 : 'range too wide to compare in one request'],
    [anaShare===null?'<span class="n flat">\\u2014</span>':'<span class="n">'+anaShare+'%</span>',
     'Med Analyzer share', tabTotal?tabTotal+' tab opens total':'no tab activity yet'],
    ['<span class="n">'+since+'</span>', since===1?'day tracking':'days tracking','since '+LAUNCH]
  ].map(k=>'<div class="kpi">'+k[0]+'<div class="l">'+k[1]+'</div><div class="s">'+k[2]+'</div></div>').join('');

  // ── roster board: one card per delegate team, in shift order ──
  /* v127: the team is read from TEAMS rather than inferred from whatever string
     happened to be in the roster's group slot, so a card can never appear for a
     team that does not exist, and every card can state its SME and the hours
     that team actually works. */
  const teams={};
  agents.forEach(([c,v])=>{ const dg=v[2]||'Unassigned'; (teams[dg]=teams[dg]||[]).push([c,v]); });
  const order=Object.keys(teams).sort((a,b)=>{
    const sa=TEAMS[a]?SHIFT_ORDER[TEAMS[a][2]]:9, sb=TEAMS[b]?SHIFT_ORDER[TEAMS[b][2]]:9;
    return sa-sb || teams[b].length-teams[a].length || a.localeCompare(b);
  });
  document.getElementById('board').innerHTML = order.map(dg=>{
    const list=teams[dg].sort((a,b)=>a[1][0].localeCompare(b[1][0]));
    const used=list.filter(([c])=>cur[c]).length;
    const t=TEAMS[dg];
    const sub = t
      ? esc(t[0])+' <span class="mono">'+esc(t[1])+'</span> \\u00b7 '+esc(SHIFT[t[2]]||'?')
        + (SHIFT_TIME[t[2]] ? ' \\u00b7 '+esc(SHIFT_TIME[t[2]]) : '')
      : esc([...new Set(list.map(([,v])=>SHIFT[v[1]]||'?'))].join(' / '));
    return '<div class="team'+(used?'':' none')+'">'
      +'<div class="top"><span class="who">'+esc(dg)+'</span>'
      +'<span class="cnt"><b>'+used+'</b> / '+list.length+'</span></div>'
      +'<div class="sh">'+sub+'</div><div class="dots">'
      + list.map(([c,v])=>{
          const n=cur[c]||0;
          return '<span class="dot'+(n>=3?' hot':n?' on':'')+'" title="'
               + esc(v[0])+' ('+c+') \\u2014 '+(n?n+' day(s) in range':'not seen in this range')+'"></span>';
        }).join('')
      +'</div></div>';
  }).join('');

  // -- charts, all scoped to the selected range --
  /* The per-agent grid below draws one column per day, so it shows the tail of
     the range rather than all of it — 90 columns is not a table anyone reads. */
  const last14 = curDays.slice(-14);
  const dailyCounts = curDays.map(dy=>agents.filter(([c])=>(byDay[dy]||new Set()).has(c)).length);
  drawDaily(curDays, dailyCounts, agents.length);
  drawTeams(cur);
  drawDepth(agents, cur, span);

  // ── tabs ──
  const tmax=Math.max(1,...Object.values(tb));
  document.getElementById('tabs').innerHTML = Object.keys(tb).length
    ? Object.entries(tb).sort((a,b)=>b[1]-a[1]).map(([k,v])=>
        '<div class="bar"><div class="lb">'+esc(TABNAME[k]||k)+'</div><div class="tr"><div class="fl" style="width:'
        +Math.max(1,Math.round(v/tmax*100))+'%"></div></div><div class="vl mono">'+v+'</div></div>').join('')
    : '<div class="empty">No tab activity recorded yet.</div>';

  // ── follow-up ──
  document.getElementById('followup').innerHTML = order.map(dg=>{
    const miss=teams[dg].filter(([c])=>!cur[c]).sort((a,b)=>a[1][0].localeCompare(b[1][0]));
    if(!miss.length) return '<details><summary><span>'+esc(dg)
      +'</span><span class="n" style="color:var(--deep)">all '+teams[dg].length+' active</span></summary></details>';
    return '<details><summary><span>'+esc(dg)+'</span><span class="n">'+miss.length
      +' to follow up</span></summary><div class="body"><div class="names">'
      + miss.map(([c,v])=>'<div>'+esc(v[0])+' <span class="mono" style="color:var(--mut)">'+c+'</span></div>').join('')
      +'</div></div></details>';
  }).join('');

  // ── day detail ──
  const dayIndex = {};
  days.forEach(x => dayIndex[x.day] = x);
  const pick = document.getElementById('dayPick');
  pick.innerHTML = days.length
    ? [...days].reverse().map(x => '<option value="' + x.day + '">' + x.day + ' \\u2014 '
        + (x.agents||[]).length + ' agent(s)</option>').join('')
    : '<option value="">no activity recorded</option>';
  function renderDay(){
    const x = dayIndex[pick.value];
    const host = document.getElementById('dayDetail');
    const sum  = document.getElementById('daySummary');
    if(!x){ host.innerHTML = '<div class="empty">Nothing recorded for this date.</div>'; sum.textContent=''; return; }
    const det = (x.detail || []).slice().sort((a,b) => (b.total||0)-(a.total||0)
                 || String((ROSTER[a.code]||[''])[0]).localeCompare(String((ROSTER[b.code]||[''])[0])));
    const grand = det.reduce((n,r) => n + (r.total||0), 0);
    const lg = x.legacy || {opens:0,tabs:0};
    sum.textContent = det.length + ' agent(s) \\u00b7 ' + grand + ' tab opens'
      + ((lg.opens || lg.tabs) ? '  \\u00b7  plus ' + (lg.opens + lg.tabs)
         + ' event(s) recorded before agent tracking (not attributable)' : '');
    const cols = TAB_COLS;
    host.innerHTML = det.length
      ? '<div class="gwrap"><table class="grid"><tr><th class="who">Agent</th>'
        + cols.map(c => '<th>' + (TABNAME[c]||c) + '</th>').join('') + '<th>Total</th><th>Team</th></tr>'
        + det.map(r => {
            const info = ROSTER[r.code] || ['Unknown','?','',0];
            const role = info[3]===0 ? (info[2] || '\\u2014') : (info[4] || '\\u2014');
            return '<tr><td class="who">' + esc(info[0])
              + '<span class="gcode mono">' + esc(r.code) + '</span></td>'
              + cols.map(c => '<td class="mono">' + ((r.counts||{})[c] || '\\u2014') + '</td>').join('')
              + '<td class="mono"><strong>' + (r.total||0) + '</strong></td>'
              + '<td style="font-size:12px;color:var(--mut)">' + esc(role) + '</td></tr>';
          }).join('') + '</table></div>'
      : '<div class="empty">Nothing recorded for this date.</div>';
  }
  pick.onchange = renderDay;
  renderDay();

  // ── individual daily activity ──
  const byCode = {}, countsByCode = {};
  days.forEach(x => (x.detail || []).forEach(r => {
    if(!r.code) return;
    (byCode[r.code] = byCode[r.code] || {})[x.day] = r.tabs || [];
    (countsByCode[r.code] = countsByCode[r.code] || {})[x.day] = r.counts || {};
  }));
  const activeAgents = Object.entries(ROSTER).filter(([c,v]) => v[3]!==3 && byCode[c])
    .sort((a,b) => Object.keys(byCode[b[0]]).length - Object.keys(byCode[a[0]]).length
                || a[1][0].localeCompare(b[1][0]));

  document.getElementById('gridwrap').innerHTML = activeAgents.length
    ? '<div class="gwrap"><table class="grid"><tr><th class="who">Agent</th>'
      + last14.map(d => '<th>' + d.slice(5) + '</th>').join('') + '</tr>'
      + activeAgents.map(([c,v]) => '<tr><td class="who" data-code="' + c + '">' + esc(v[0])
          + '<span class="gcode mono">' + c + '</span></td>'
          + last14.map(d => {
              const t = (byCode[c] || {})[d];
              const cls = !t ? '' : (t.length >= 3 ? ' hot' : ' on');
              const cts = (countsByCode[c] || {})[d];
              const title = t
                ? d + ' \\u2014 ' + (t.length
                    ? t.map(x => (TABNAME[x] || x) + (cts && cts[x] ? ' \\u00d7' + cts[x] : '')).join(', ')
                    : 'opened, no tab recorded')
                : d + ' \\u2014 not seen';
              return '<td><span class="cell' + cls + '" title="' + esc(title) + '"></span></td>';
            }).join('') + '</tr>').join('')
      + '</table></div>'
    : '<div class="empty">No individual activity recorded yet.</div>';

  document.querySelectorAll('td.who').forEach(td => td.onclick = () => {
    const c = td.getAttribute('data-code');
    const info = ROSTER[c] || ['Unknown','?','',0];
    const rows = Object.entries(byCode[c] || {}).sort((a,b) => b[0].localeCompare(a[0]));
    document.getElementById('agentDetail').innerHTML =
      '<div class="detail"><h3>' + esc(info[0]) + ' <span class="mono" style="color:var(--mut)">' + c
      + '</span> \\u2014 ' + (SHIFT[info[1]] || '?') + (info[2] ? ' \\u00b7 ' + esc(info[2]) : '') + '</h3>'
      + (rows.length
          ? '<table><tr><th>Date</th><th>Tabs opened</th></tr>'
            + rows.map(([d,t]) => '<tr><td class="mono">' + d + '</td><td>'
                + (t.length ? t.map(x => '<span class="tabchip">' + esc(TABNAME[x] || x)
                    + (((countsByCode[c]||{})[d]||{})[x] ? ' \\u00d7' + (countsByCode[c][d][x]) : '') + '</span>').join('')
                            : '<span style="color:var(--mut)">opened, no tab recorded</span>')
                + '</td></tr>').join('')
            + '</table>'
          : '<div class="empty">No days recorded.</div>')
      + '</div>';
  });

  // ── unrecognised medications ──
  const unk = d.unknownMeds || [];
  document.getElementById('unknown').innerHTML = unk.length
    ? '<table><tr><th>Medication text</th><th>Times seen</th><th>Agents</th><th>Last</th></tr>'
      + unk.slice(0,60).map(u=>'<tr><td class="mono">'+esc(u.name)+'</td><td class="mono">'+u.total
        +'</td><td class="mono">'+u.agents+'</td><td class="mono">'+esc(u.last||'')+'</td></tr>').join('')
      + '</table>'
    : '<div class="empty">Nothing reported yet. Agents send these from the Med Analyzer when the tool cannot identify a medication.</div>';

  // ── leadership ──
  const qaRows=qa.map(([c,v])=>({c,name:v[0],sh:v[1],t:v[4]||'',n:cur[c]||0}))
    .sort((a,b)=>b.n-a.n||a.name.localeCompare(b.name));
  document.getElementById('qa').innerHTML = qaRows.length
    ? '<table><tr><th>Name</th><th>Code</th><th>Role</th><th>Shift</th><th>Days in range</th></tr>'
      + qaRows.map(l=>'<tr><td>'+esc(l.name)+'</td><td class="mono">'+l.c+'</td><td>'
        +esc(l.t||'\\u2014')+'</td><td>'
        +(SHIFT[l.sh]||'?')+'</td><td class="mono">'+(l.n||'\\u2014')+'</td></tr>').join('')+'</table>'
    : '<div class="empty">None.</div>';

  /* v127: leadership is grouped by shift, the way Mohamed's own sheet shows it,
     with the scheduled hours beside each shift. Within a shift it reads down the
     line: Account Manager, TL, DTL, then the SMEs. */
  const RANK={'Account Manager':0,'TL':1,'DTL':2,'SME':3};
  const lead=leaders.map(([c,v])=>({c,name:v[0],sh:v[1],t:v[4]||'',n:cur[c]||0}));
  document.getElementById('leaders').innerHTML = ['M','A','N','O'].map(sh=>{
    const rows=lead.filter(l=>l.sh===sh)
      .sort((a,b)=>(RANK[a.t]===undefined?9:RANK[a.t])-(RANK[b.t]===undefined?9:RANK[b.t])
                 ||a.name.localeCompare(b.name));
    if(!rows.length) return '';
    return '<h3 class="shifthead">'+esc(SHIFT[sh]||'?')
      + (SHIFT_TIME[sh] ? ' <span>'+esc(SHIFT_TIME[sh])+'</span>' : '')
      + ' <span>'+rows.length+'</span></h3>'
      +'<table><tr><th>Name</th><th>Code</th><th>Role</th><th>Days in range</th></tr>'
      + rows.map(l=>'<tr><td>'+esc(l.name)+'</td><td class="mono">'+l.c+'</td><td>'
        +esc(l.t||'\\u2014')+'</td><td class="mono">'+(l.n||'\\u2014')+'</td></tr>').join('')
      +'</table>';
  }).join('');
}
</script>
<div class="tip" id="tip"></div>
</body></html>
`;
