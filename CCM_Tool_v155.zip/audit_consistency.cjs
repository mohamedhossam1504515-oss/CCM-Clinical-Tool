/* Cross-check: the Reference tab search (#search) and the Problem Note
   Generator search (#cpSearch) must never disagree about who owns an ICD code.

   The two boxes speak different namespaces: Reference returns TOOL PAGE names,
   cpSearch returns CARE PLAN names. A care plan entry declares which tool page
   it belongs to via maps_to, so cp hits are translated through maps_to before
   comparing. Care-plan-only entries (maps_to null) have no tool page and are
   ignored for this comparison.

   Usage: node audit_consistency.cjs [index.html] [--json out.json]
*/
const { chromium } = require('playwright');
const fs = require('fs');

const file = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : 'index.html';
const jsonIdx = process.argv.indexOf('--json');
const jsonOut = jsonIdx !== -1 ? process.argv[jsonIdx + 1] : null;

(async () => {
  const base = process.env.CCM_BASE || 'http://127.0.0.1:8899';
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run'] });
  const page = await browser.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  await page.route('**/*', r => (r.request().url().startsWith(base) ? r.continue() : r.abort()));
  await page.addInitScript(() => {
    /* v133 bumped the saved-identity key. Seed BOTH so this script loads already signed in whichever build it is pointed at. */
    try { localStorage.setItem('ccm_agent_v1', JSON.stringify({ name: 'AUDIT HARNESS', code: '', id: 'audit' })); } catch (e) {}
    try { localStorage.setItem('ccm_agent_v2', JSON.stringify({ name: 'AUDIT HARNESS', code: '', id: 'audit' })); } catch (e) {}
  });
  await page.goto(base + '/' + file);
  await page.waitForFunction(() => {
    const t = document.getElementById('tab-careplan');
    return t && !t.disabled;
  }, { timeout: 30000 });

  const codes = await page.evaluate(() => Object.keys(CODE_TO_COND).sort());
  const mapsTo = await page.evaluate(() => {
    const cp = (CCM_DATA && CCM_DATA.care_plan) || {};
    const o = {};
    Object.keys(cp).forEach(n => { o[n] = cp[n].maps_to || null; });
    return o;
  });

  // Two passes, one tab switch each — switching tabs per code is far too slow.
  const refBy = {}, cpBy = {};

  await page.click('#tab-careplan');            // runs cpInit()
  await page.waitForSelector('#cpSearch', { state: 'visible' });
  for (let i = 0; i < codes.length; i++) {
    await page.fill('#cpSearch', codes[i]);
    cpBy[codes[i]] = await page.evaluate(() =>
      Array.from(document.querySelectorAll('#cpResults .cp-opt')).map(e => e.getAttribute('data-name')));
    if ((i + 1) % 400 === 0) console.log(`  cp   ...${i + 1}/${codes.length}`);
  }

  await page.click('#tab-reference');
  await page.waitForSelector('#search', { state: 'visible' });
  for (let i = 0; i < codes.length; i++) {
    await page.fill('#search', codes[i]);
    refBy[codes[i]] = await page.evaluate(() =>
      Array.from(document.querySelectorAll('.cond-item')).map(e => e.textContent.trim()));
    if ((i + 1) % 400 === 0) console.log(`  ref  ...${i + 1}/${codes.length}`);
  }

  // The Reference sidebar renders shortName(cond), which strips parentheticals.
  // Use the PAGE'S OWN shortName so this harness never reimplements app logic.
  const rows = [];
  for (const code of codes) {
    const cpRaw = cpBy[code];
    const cpPages = await page.evaluate(pages =>
      [...new Set(pages.map(p => (typeof shortName === 'function' ? shortName(p) : p)))],
      [...new Set(cpRaw.map(n => mapsTo[n]).filter(Boolean))]);
    rows.push({ code, ref: refBy[code], cpRaw, cpPages });
  }
  await browser.close();

  const eq = (a, b) => a.length === b.length && [...a].sort().join('|') === [...b].sort().join('|');
  const disagree = rows.filter(r => r.ref.length && r.cpPages.length && !eq(r.ref, r.cpPages));
  const refMulti = rows.filter(r => r.ref.length > 1);
  const cpMulti  = rows.filter(r => r.cpRaw.length > 1);

  console.log(`\ncodes checked      : ${rows.length}`);
  console.log(`Reference MULTI    : ${refMulti.length}`);
  console.log(`ProblemNote MULTI  : ${cpMulti.length}`);
  console.log(`BOXES DISAGREE     : ${disagree.length}`);

  for (const d of disagree.slice(0, 60)) {
    console.log(`  ${d.code.padEnd(10)} ref=[${d.ref.join(' | ')}]  cp=[${d.cpPages.join(' | ')}]`);
  }
  if (errs.length) { console.log('\nPAGE ERRORS:'); errs.forEach(e => console.log('  ' + e)); }

  if (jsonOut) fs.writeFileSync(jsonOut, JSON.stringify({ rows, disagree, errs }, null, 2));
  process.exit(0);
})();
