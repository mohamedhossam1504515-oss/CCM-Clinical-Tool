/* Exhaustive ICD-code disambiguation audit.
   Drives the REAL #cpSearch box in the REAL page — no reimplementation of
   app logic. For every code in CODE_TO_COND, types the code and reads the
   rendered #cpResults list, classifying the outcome as ONE / MULTI / EMPTY.

   Usage: node audit_search.cjs [index.html] [--json out.json]
*/
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const file = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : 'index.html';
const jsonIdx = process.argv.indexOf('--json');
const jsonOut = jsonIdx !== -1 ? process.argv[jsonIdx + 1] : null;

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run'] });
  const page = await browser.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  const base = process.env.CCM_BASE || 'http://127.0.0.1:8899';
  // never let the adoption beacon leave the box during a test run
  await page.route('**/*', route => {
    const u = route.request().url();
    if (u.startsWith(base) || u.startsWith('data:') || u.startsWith('blob:')) return route.continue();
    return route.abort();
  });
  // returning-agent state, so the identity gate does not overlay the UI
  await page.addInitScript(() => {
    try {
      /* v133 bumped the saved-identity key. Seed BOTH so this script loads already signed in whichever build it is pointed at. */
      localStorage.setItem('ccm_agent_v1', JSON.stringify({ name: 'AUDIT HARNESS', code: '', id: 'audit' }));
      localStorage.setItem('ccm_agent_v2', JSON.stringify({ name: 'AUDIT HARNESS', code: '', id: 'audit' }));
    } catch (e) {}
  });
  await page.goto(base + '/' + file);
  // boot() disables every tab until ccmLoadData() resolves
  await page.waitForFunction(() => {
    const t = document.getElementById('tab-careplan');
    return t && !t.disabled;
  }, { timeout: 30000 });
  await page.click('#tab-careplan');
  await page.waitForSelector('#cpSearch', { state: 'visible' });

  const codes = await page.evaluate(() => Object.keys(CODE_TO_COND).sort());
  console.log(`codes in CODE_TO_COND: ${codes.length}`);

  const box = page.locator('#cpSearch');
  await box.click();

  const results = [];
  for (let i = 0; i < codes.length; i++) {
    const code = codes[i];
    await box.fill(code);
    // read whatever the real UI rendered
    const hits = await page.evaluate(() => {
      const list = document.getElementById('cpResults');
      if (!list) return null;
      return Array.from(list.querySelectorAll('.cp-opt')).map(el => el.getAttribute('data-name'));
    });
    results.push({ code, hits: hits || [] });
    if ((i + 1) % 200 === 0) console.log(`  ...${i + 1}/${codes.length}`);
  }

  await browser.close();

  const multi = results.filter(r => r.hits.length > 1);
  const empty = results.filter(r => r.hits.length === 0);
  const one = results.filter(r => r.hits.length === 1);

  console.log(`\nONE  : ${one.length}`);
  console.log(`MULTI: ${multi.length}`);
  console.log(`EMPTY: ${empty.length}`);

  if (multi.length) {
    console.log('\n── MULTI (code resolves to more than one condition) ──');
    for (const m of multi) console.log(`  ${m.code.padEnd(10)} -> ${m.hits.join(' | ')}`);
  }
  if (empty.length) {
    console.log('\n── EMPTY (code resolves to no condition) ──');
    for (const e of empty) console.log(`  ${e.code}`);
  }
  if (errs.length) {
    console.log('\n── PAGE ERRORS ──');
    errs.forEach(e => console.log('  ' + e));
  }

  if (jsonOut) {
    const all = {};
    for (const r of results) all[r.code] = r.hits;
    fs.writeFileSync(jsonOut, JSON.stringify({ total: results.length, one: one.length, multi, empty, errs, all }, null, 2));
    console.log(`\nwrote ${jsonOut}`);
  }
  process.exit(0);
})();
