# -*- coding: utf-8 -*-
"""Extract / splice the live dashboard page out of and back into _worker.js.

/dashboard is served from a template literal, so editing it means escaping
backslashes, backticks and ${. Both directions were proven byte-exact against
the literal already in the file at v129.

    python3 dashtool.py extract  > writes dashboard.work.html
    python3 dashtool.py splice   < reads dashboard.work.html
"""
import sys, os

W = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_worker.js')
WORK = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dashboard.work.html')
MARK = 'const DASHBOARD = `'

def must(c, m):
    if not c: print('ASSERTION FAILED: ' + m); sys.exit(1)

def escape(s):
    return s.replace('\\', '\\\\').replace('`', '\\`').replace('${', '\\${')

def unescape(s):
    out = []; n = 0
    while n < len(s):
        if s[n] == '\\' and n + 1 < len(s) and s[n + 1] in '\\`$':
            out.append(s[n + 1]); n += 2; continue
        out.append(s[n]); n += 1
    return ''.join(out)

def span(w):
    must(w.count(MARK) == 1, 'DASHBOARD marker appears %d times' % w.count(MARK))
    i = w.index(MARK) + len(MARK)
    j = i
    while True:
        j = w.index('`', j)
        bs = 0; k = j - 1
        while k >= 0 and w[k] == '\\': bs += 1; k -= 1
        if bs % 2 == 0: break
        j += 1
    return i, j

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    w = open(W, encoding='utf-8').read()
    i, j = span(w)
    if cmd == 'extract':
        html = unescape(w[i:j])
        must(escape(html) == w[i:j], 'round-trip failed on extract — refusing')
        open(WORK, 'w', encoding='utf-8').write(html)
        print('extracted %d bytes to %s' % (len(html), os.path.basename(WORK)))
    elif cmd == 'splice':
        html = open(WORK, encoding='utf-8').read()
        lit = escape(html)
        must(unescape(lit) == html, 'round-trip failed on splice — refusing')
        must('`' not in lit.replace('\\`', ''), 'an unescaped backtick survived')
        must('<title>CCM Tool' in html, 'this does not look like the dashboard')
        open(W, 'w', encoding='utf-8').write(w[:i] + lit + w[j:])
        w2 = open(W, encoding='utf-8').read()
        i2, j2 = span(w2)
        must(unescape(w2[i2:j2]) == html, 'spliced literal does not read back as the page')
        print('spliced %d bytes into _worker.js' % len(html))
    else:
        print(__doc__); sys.exit(1)

main()
