/* Prove the COPD/Emphysema split is a real behavior change: on the pre-split
   build, J44.9 and J43.9 both resolved to the same combined care-plan entry;
   on the split build, they resolve to two distinct ones. */
const { chromium } = require('playwright');
const base = process.env.CCM_BASE || 'http://127.0.0.1:8899';
const file = process.argv[2] || 'index.html';

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    args: ['--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run'] });
  const page = await browser.newPage();
  await page.route('**/*', r => (r.request().url().startsWith(base) ? r.continue() : r.abort()));
  await page.addInitScript(() => { try { navigator.sendBeacon = () => true;
    /* v133 bumped the saved-identity key. Seed BOTH so this script loads already signed in whichever build it is pointed at. */
    localStorage.setItem('ccm_agent_v1', JSON.stringify({ name: 'repro', id: 'r' }));
    localStorage.setItem('ccm_agent_v2', JSON.stringify({ name: 'repro', id: 'r' })); } catch (e) {} });
  await page.goto(base + '/' + file);
  await page.waitForFunction(() => { const t = document.getElementById('tab-careplan'); return t && !t.disabled; }, { timeout: 30000 });
  const build = await page.evaluate(() => document.querySelector('[data-version-stamp]').textContent);
  await page.click('#tab-careplan');
  await page.waitForSelector('#cpSearch', { state: 'visible' });

  const search = async q => { await page.fill('#cpSearch', q); await page.waitForTimeout(100);
    return page.evaluate(() => Array.from(document.querySelectorAll('#cpResults .cp-opt')).map(e => e.getAttribute('data-name'))); };

  const copd = await search('J44.9');
  const emph = await search('J43.9');
  console.log('build:', build);
  console.log('J44.9 ->', copd);
  console.log('J43.9 ->', emph);
  console.log(copd.length === 1 && emph.length === 1 && copd[0] === emph[0]
    ? 'STILL COMBINED (no distinction)'
    : 'DISTINCT');
  await browser.close();
})();
