/* Exact repro of Mohamed's screenshot: type j44.9 into the Problem Note
   Generator search box and print the FULL result list, plus the reference
   page line and generated note, so nothing is missed by a cropped screenshot. */
const { chromium } = require('playwright');
const base = process.env.CCM_BASE || 'http://127.0.0.1:8899';
const file = process.argv[2] || 'index.html';

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    args: ['--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run'] });
  const page = await browser.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.route('**/*', r => (r.request().url().startsWith(base) ? r.continue() : r.abort()));
  await page.addInitScript(() => { try { navigator.sendBeacon = () => true;
    /* v133 bumped the saved-identity key. Seed BOTH so this script loads already signed in whichever build it is pointed at. */
    localStorage.setItem('ccm_agent_v1', JSON.stringify({ name: 'repro', id: 'r' }));
    localStorage.setItem('ccm_agent_v2', JSON.stringify({ name: 'repro', id: 'r' })); } catch (e) {} });
  await page.goto(base + '/' + file);
  await page.waitForFunction(() => { const t = document.getElementById('tab-careplan'); return t && !t.disabled; }, { timeout: 30000 });

  const build = await page.evaluate(() => document.querySelector('[data-version-stamp]').textContent);
  console.log('build:', build);

  await page.click('#tab-careplan');
  await page.waitForSelector('#cpSearch', { state: 'visible' });
  await page.fill('#cpSearch', 'j44.9');
  await page.waitForTimeout(150);

  const hits = await page.evaluate(() =>
    Array.from(document.querySelectorAll('#cpResults .cp-opt')).map(el => ({
      name: el.getAttribute('data-name'),
      text: el.textContent.trim()
    })));
  console.log('\ncpResults for "j44.9":', JSON.stringify(hits, null, 2));

  if (hits.length) {
    await page.locator('#cpResults .cp-opt').first().click();
    await page.waitForTimeout(300);
    const refLine = await page.evaluate(() => {
      const el = [...document.querySelectorAll('#cpBody div')].find(d => /Reference page:/.test(d.textContent));
      return el ? el.textContent.trim() : null;
    });
    console.log('\n"Reference page:" line shown:', refLine);
    const condLabel = await page.evaluate(() => document.getElementById('cpCond').value);
    console.log('selected condition (hidden select value):', condLabel);
  }
  if (errs.length) { console.log('\nPAGE ERRORS:'); errs.forEach(e => console.log('  ' + e)); }
  await browser.close();
})();
