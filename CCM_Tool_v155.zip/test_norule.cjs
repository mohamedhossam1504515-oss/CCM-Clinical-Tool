/* Real-UI check of the v99 "no normal range" lab rows.
   Drives the actual Problem Note Generator: picks a condition, inspects the
   rendered rows, types into them and reads back the generated analysis text.
   Nothing here reimplements app logic. */
const { chromium } = require('playwright');

const file = process.argv[2] || 'index.html';
const base = process.env.CCM_BASE || 'http://127.0.0.1:8899';
let pass = 0, fail = 0; const fails = [];
const T = (n, c) => { c ? pass++ : (fail++, fails.push(n)); console.log(`  ${c ? 'ok  ' : 'FAIL'}  ${n}`); };

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    args: ['--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run'] });
  const page = await browser.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e)));
  await page.route('**/*', r => (r.request().url().startsWith(base) ? r.continue() : r.abort()));
  await page.addInitScript(() => { try { navigator.sendBeacon = () => true;
    /* v133 bumped the saved-identity key. Seed BOTH so this script loads already signed in whichever build it is pointed at. */
    localStorage.setItem('ccm_agent_v1', JSON.stringify({ name: 'norule-test', id: 't' }));
    localStorage.setItem('ccm_agent_v2', JSON.stringify({ name: 'norule-test', id: 't' })); } catch (e) {} });
  await page.goto(base + '/' + file);
  await page.waitForFunction(() => { const t = document.getElementById('tab-careplan'); return t && !t.disabled; }, { timeout: 30000 });
  await page.click('#tab-careplan');
  await page.waitForSelector('#cpSearch', { state: 'visible' });

  // pick COPD through the real search box + real option click
  await page.fill('#cpSearch', 'COPD');
  await page.waitForTimeout(120);
  await page.locator('#cpResults .cp-opt', { hasText: 'COPD' }).first().click();
  await page.waitForSelector('#labRows', { timeout: 10000 });

  const shape = await page.evaluate(() => {
    const o = {};
    document.querySelectorAll('#labRows tr[data-labrow]').forEach(tr => {
      o[tr.getAttribute('data-labname')] = {
        norule: !!tr.getAttribute('data-norule'),
        hasPrev: !!tr.querySelector('[data-lprev]'),
        hasStatusCell: !!tr.querySelector('[data-lstatus]'),
        monOpts: tr.querySelector('[data-lmon]')
          ? Array.from(tr.querySelectorAll('[data-lmon] option')).map(x => x.value) : null,
        cells: tr.querySelectorAll('td').length
      };
    });
    return o;
  });

  console.log('\nrows rendered for COPD:');
  Object.entries(shape).forEach(([k, v]) => console.log(`   ${v.norule ? 'NORULE' : 'numeric'}  ${k}`));
  console.log('');

  /* v146: pneumococcal moved from Numbers To Track to the PNU care gap (his
     19 Oct sheet); PFT is COPD's only no-rule row, so it carries both roles. */
  const PN = 'Pulmonary Function Test', PFT = 'Pulmonary Function Test';
  T('Pneumococcal vaccine status is no longer a lab row (v146)', !('Pneumococcal vaccine status' in shape));
  T(`${PFT} is a no-rule row`, shape[PFT] && shape[PFT].norule);
  T('COPD renders exactly one no-rule lab row (PFT)', Object.keys(shape).length === 1);
  T(`${PFT} has no prev/result numeric inputs`, shape[PFT] && !shape[PFT].hasPrev);
  T(`${PN} offers the monitoring statuses`,
    shape[PN] && JSON.stringify(shape[PN].monOpts) === JSON.stringify(['', 'Monitored', 'Not monitored this cycle']));
  /* v142 added a Recency column (9-column grid): name + normal + finding(colspan 3)
     + date + status + recency + comment = 7 cells. */
  T('no-rule row keeps the 9-column grid',
    shape[PN] && shape[PN].cells === 7);

  T('Weight is not in the labs table (it is a vital)', !('Weight' in shape));

  /* COPD happens to carry ONLY no-rule rows, so ordinary numeric
     rows must be checked on a condition that actually has them, or the
     assertion passes/fails vacuously. */
  await page.fill('#cpSearch', 'Diabetes mellitus');
  await page.waitForTimeout(120);
  await page.locator('#cpResults .cp-opt', { hasText: 'Diabetes mellitus' }).first().click();
  await page.waitForTimeout(300);
  const dm = await page.evaluate(() => {
    const o = {};
    document.querySelectorAll('#labRows tr[data-labrow]').forEach(tr => {
      o[tr.getAttribute('data-labname')] = {
        norule: !!tr.getAttribute('data-norule'),
        hasPrev: !!tr.querySelector('[data-lprev]'),
        hasStatusCell: !!tr.querySelector('[data-lstatus]')
      };
    });
    return o;
  });
  const numeric = Object.entries(dm).filter(([, v]) => !v.norule);
  console.log(`\n  Diabetes mellitus: ${numeric.length} numeric row(s), ` +
              `${Object.keys(dm).length - numeric.length} no-rule row(s)`);
  T('a condition with numeric labs actually has some', numeric.length >= 3);
  T('numeric rows still have prev + status cell',
    numeric.length > 0 && numeric.every(([, v]) => v.hasPrev && v.hasStatusCell));

  // an ordinary numeric lab must still be judged, i.e. issue 1 changed nothing there
  const a1c = Object.keys(dm).find(k => /A1c/i.test(k));
  if (a1c) {
    await page.fill(`#labRows tr[data-labname="${a1c}"] [data-lcur]`, '9.4');
    await page.waitForTimeout(150);
    const st = await page.textContent(`#labRows tr[data-labname="${a1c}"] [data-lstatus]`);
    T(`${a1c} 9.4 is still judged (got "${st.trim()}")`, st.trim() === 'Abnormal');
  } else {
    T('found an A1c row to re-check numeric judging', false);
  }

  // back to COPD for the remaining no-rule assertions
  await page.fill('#cpSearch', 'COPD');
  await page.waitForTimeout(120);
  await page.locator('#cpResults .cp-opt', { hasText: 'COPD' }).first().click();
  await page.waitForSelector('#labRows', { timeout: 10000 });

  // "Not monitored this cycle" with no finding typed
  await page.selectOption(`#labRows tr[data-labname="${PN}"] [data-lmon]`, 'Not monitored this cycle');
  await page.waitForTimeout(150);
  let analysis = await page.inputValue('#labOut');
  T('not-monitored produces a sentence in the analysis',
    /Pulmonary Function Test not monitored this cycle/.test(analysis));
  T('not-monitored is never called Normal or Abnormal',
    !/Pulmonary Function Test[\s\S]{0,160}\b(Normal|Abnormal)\b/.test(analysis));

  // a real finding + date, marked Monitored
  await page.fill(`#labRows tr[data-labname="${PFT}"] [data-lcur]`, 'FEV1/FVC 62% predicted');
  await page.fill(`#labRows tr[data-labname="${PFT}"] [data-lcurd]`, '03/12/25');
  await page.selectOption(`#labRows tr[data-labname="${PFT}"] [data-lmon]`, 'Monitored');
  await page.waitForTimeout(150);
  analysis = await page.inputValue('#labOut');
  T('finding text and date reach the analysis',
    /FEV1\/FVC 62% predicted/.test(analysis) && /03\/12\/25/.test(analysis));
  T('a free-text finding is never judged Normal/Abnormal',
    !/FEV1\/FVC 62% predicted[\s\S]{0,60}\((Normal|Abnormal)\)/.test(analysis));

  // survives a labs re-render (snapshot/restore round trip)
  await page.fill('#cpBody textarea[data-fill="medications"]', 'tiotropium 18 mcg daily');
  await page.waitForTimeout(400);
  const kept = await page.evaluate(pft => {
    const tr = document.querySelector(`#labRows tr[data-labname="${pft}"]`);
    return tr ? { cur: tr.querySelector('[data-lcur]').value, mon: tr.querySelector('[data-lmon]').value } : null;
  }, PFT);
  T('finding survives a labs re-render', kept && kept.cur === 'FEV1/FVC 62% predicted');
  T('monitoring status survives a labs re-render', kept && kept.mon === 'Monitored');

  T('no page JS errors', errs.length === 0);
  if (errs.length) errs.forEach(e => console.log('   ' + e));

  console.log(`\n  PASS ${pass}   FAIL ${fail}`);
  if (fail) { console.log('  failing:'); fails.forEach(f => console.log('   x ' + f)); }
  await browser.close();
  process.exit(fail ? 1 : 0);
})();
